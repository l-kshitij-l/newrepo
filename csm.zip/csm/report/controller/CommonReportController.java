package com.concerto.prm.csm.report.controller;

import java.util.List;

//import lombok.Generated;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.aciworldwide.rms.ar.grid.common.model.DataGridRequestModel;
import com.concerto.prm.csm.report.service.CommonReportService;

@RestController
@RequestMapping("/api/csm-report")
public class CommonReportController {

	@Autowired
	private CommonReportService commonReportService;
	//@Generated
	//public static final String APPLICATIN_LOGGER = "AppLogger";
	//public static Logger logger = LoggerFactory.getLogger(APPLICATIN_LOGGER);

	@RequestMapping(method = RequestMethod.POST, path = "/get-grouped-grid/{viewName}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public Object getAsGrid(@PathVariable(name = "viewName") String viewName,
			@RequestBody(required = false) DataGridRequestModel dataRequestModel) {
		//logger.info("Inside Controller getAsGrid method");
		if (viewName.equalsIgnoreCase("sms-report-detail") || viewName.equalsIgnoreCase("email-report-detail")) {
			return commonReportService.getAsGrid(dataRequestModel, viewName);
		} else if (viewName.equalsIgnoreCase("full-action-report-summary")) {
			return commonReportService.getAsGrid(dataRequestModel, viewName);
		} else if (viewName.equalsIgnoreCase("mark-block-report-summary")) {
			return commonReportService.getAsGrid(dataRequestModel, viewName);
		} else {
			return commonReportService.getAsGroupGrid(dataRequestModel, viewName);
		}
	}

	@RequestMapping(method = RequestMethod.GET, path = "/get-channel-name/{viewName}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.OK)
	public List<String> getChannelName(@PathVariable(name = "viewName") String viewName) {
		return commonReportService.getChannelName(viewName);
	}

}