package com.concerto.prm.csm.report.controller;

import java.io.IOException;

import javax.xml.transform.TransformerException;

import org.apache.fop.apps.FOPException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.aciworldwide.rms.ar.grid.common.model.ExportDataGridRequestModel;
import com.concerto.prm.csm.report.service.CommonReportExportService;

@RestController
@RequestMapping("/api/csm-report-export")
public class CommonReportExportController {

	@Autowired
	private CommonReportExportService dataExportService;

	@RequestMapping(method = RequestMethod.POST, path = "/export-grid-pdf", produces = { "application/octet-stream" })
	@ResponseBody
	public ResponseEntity<?> exportPDF(@RequestBody ExportDataGridRequestModel requestModel)
			throws FOPException, TransformerException, IOException {
		return dataExportService.exportToPDF(requestModel);
	}

	@RequestMapping(method = RequestMethod.POST, path = "/export-grid-csv", consumes = {
			"application/json" }, produces = { "application/octet-stream" })
	@ResponseBody
	public ResponseEntity<?> exportCSV(@RequestBody ExportDataGridRequestModel requestModel)
			throws FOPException, TransformerException, IOException {
		return dataExportService.exportToCsv(requestModel, "CSV");
	}

	@RequestMapping(method = RequestMethod.POST, path = "/export-grid-xls", consumes = {
			"application/json" }, produces = { "application/octet-stream" })
	@ResponseBody
	public ResponseEntity<?> exportXLSX(@RequestBody ExportDataGridRequestModel requestModel)
			throws FOPException, TransformerException, IOException {
		return dataExportService.exportToXlsx(requestModel);
	}

}