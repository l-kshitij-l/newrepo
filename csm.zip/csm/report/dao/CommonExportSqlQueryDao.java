package com.concerto.prm.csm.report.dao;

import org.springframework.stereotype.Service;

import com.concerto.prm.aop.ExecutionTimeLogger;

@Service
public class CommonExportSqlQueryDao {

	@ExecutionTimeLogger
	protected String getSMSExportMaskedSummaryReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getExportMaskedCardSummaryReport";
				break;
			case "PREPAID CARD":
				result = "getExportMaskedPrepaidCardSummaryReport";
				break;
			case "RINB":
				result = "getExportMaskedRinbSummaryReport";
				break;
			case "UPI":
				result = "getExportMaskedUpiSummaryReport";
				break;
			case "YONO":
				result = "getExportMaskedYonoSummaryReport";
				break;
			case "YONO LITE":
				result = "getExportMaskedYonoLiteSummaryReport";
				break;
			case "FASTag":
				result = "getExportMaskedFastTagSummaryReport";
				break;
			case "CINB":
				result = "getExportMaskedCinbSummaryReport";
				break;
			case "KIOSK":
				result = "getExportMaskedKioskSummaryReport";
				break;
			case "CBDC":
				result = "getExportMaskedCbdcSummaryReport";
				break;
			case "YONO 2.0":
				result = "getExportMaskedYn20SummaryReport";
				break;
			case "CMPI":
				result = "getExportMaskedCMPISummaryReport";
				break;
			// New channels added
			case "UPFI":
				result = "getExportMaskedUPFISummaryReport";
				break;
			case "IMPC":
				result = "getExportMaskedIMPCSummaryReport";
				break;
			case "NEFC":
				result = "getExportMaskedNEFCSummaryReport";
				break;
			case "RTGC":
				result = "getExportMaskedRTGCSummaryReport";
				break;
			default:
				result = "getExportMaskedDefaultSummaryReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getSMSExportSummaryReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getExportCardSummaryReport";
				break;
			case "PREPAID CARD":
				result = "getExportPrepaidCardSummaryReport";
				break;
			case "RINB":
				result = "getExportRinbSummaryReport";
				break;
			case "UPI":
				result = "getExportUpiSummaryReport";
				break;
			case "YONO":
				result = "getExportYonoSummaryReport";
				break;
			case "YONO LITE":
				result = "getExportYonoLiteSummaryReport";
				break;
			case "FASTag":
				result = "getExportFastTagSummaryReport";
				break;
			case "CINB":
				result = "getCinbSummaryReport";
				break;
			case "KIOSK":
				result = "getExportKioskSummaryReport";
				break;
			case "CBDC":
				result = "getExportCbdcSummaryReport";
				break;
			case "YONO 2.0":
				result = "getExportYn20SummaryReport";
				break;
			case "CMPI":
				result = "getExportCMPISummaryReport";
				break;
			// New channels added
			case "UPFI":
				result = "getExportUPFISummaryReport";
				break;
			case "IMPC":
				result = "getExportIMPCSummaryReport";
				break;
			case "NEFC":
				result = "getExportNEFCSummaryReport";
				break;
			case "RTGC":
				result = "getExportRTGCSummaryReport";
				break;
			default:
				result = "getExportDefaultSummaryReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getSMSArExportSummaryReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArExportCardSummaryReport";
				break;
			case "PREPAID CARD":
				result = "getArExportPrepaidCardSummaryReport";
				break;
			case "RINB":
				result = "getArExportRinbSummaryReport";
				break;
			case "UPI":
				result = "getArExportUpiSummaryReport";
				break;
			case "YONO":
				result = "getArExportYonoSummaryReport";
				break;
			case "YONO LITE":
				result = "getArExportYonoLiteSummaryReport";
				break;
			case "FASTag":
				result = "getArExportFastTagSummaryReport";
				break;
			case "CINB":
				result = "getArCinbSummaryReport";
				break;
			case "KIOSK":
				result = "getArExportKioskSummaryReport";
				break;
			case "CBDC":
				result = "getArExportCbdcSummaryReport";
				break;
			case "YONO 2.0":
				result = "getArExportYn20SummaryReport";
				break;
			case "CMPI":
				result = "getArExportCMPISummaryReport";
				break;
			// New channels added
			case "UPFI":
				result = "getArExportUPFISummaryReport";
				break;
			case "IMPC":
				result = "getArExportIMPCSummaryReport";
				break;
			case "NEFC":
				result = "getArExportNEFCSummaryReport";
				break;
			case "RTGC":
				result = "getArExportRTGCSummaryReport";
				break;
			default:
				result = "getArExportDefaultSummaryReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getSMSArExportMaskedSummaryReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArExportMaskedCardSummaryReport";
				break;
			case "PREPAID CARD":
				result = "getArExportMaskedPrepaidCardSummaryReport";
				break;
			case "RINB":
				result = "getArExportMaskedRinbSummaryReport";
				break;
			case "UPI":
				result = "getArExportMaskedUpiSummaryReport";
				break;
			case "YONO":
				result = "getArExportMaskedYonoSummaryReport";
				break;
			case "YONO LITE":
				result = "getArExportMaskedYonoLiteSummaryReport";
				break;
			case "FASTag":
				result = "getArExportMaskedFastTagSummaryReport";
				break;
			case "CINB":
				result = "getArExportMaskedCinbSummaryReport";
				break;
			case "KIOSK":
				result = "getArExportMaskedKioskSummaryReport";
				break;
			case "CBDC":
				result = "getArExportMaskedCbdcSummaryReport";
				break;
			case "YONO 2.0":
				result = "getArExportMaskedYn20SummaryReport";
				break;
			case "CMPI":
				result = "getArExportMaskedCMPISummaryReport";
				break;
			// New channels added
			case "UPFI":
				result = "getArExportMaskedUPFISummaryReport";
				break;
			case "IMPC":
				result = "getArExportMaskedIMPCSummaryReport";
				break;
			case "NEFC":
				result = "getArExportMaskedNEFCSummaryReport";
				break;
			case "RTGC":
				result = "getArExportMaskedRTGCSummaryReport";
				break;
			default:
				result = "getArExportDefaultSummaryReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getEmailExportSummaryReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getExportEmailCardSummaryReport";
				break;
			case "PREPAID CARD":
				result = "getExportEmailPrepaidCardSummaryReport";
				break;
			case "RINB":
				result = "getExportEmailRinbSummaryReport";
				break;
			case "UPI":
				result = "getExportEmailUpiSummaryReport";
				break;
			case "YONO":
				result = "getExportEmailYonoSummaryReport";
				break;
			case "YONO LITE":
				result = "getExportEmailYonoLiteSummaryReport";
				break;
			case "FASTag":
				result = "getExportEmailFastTagSummaryReport";
				break;
			case "CINB":
				result = "getExportEmailCinbSummaryReport";
				break;
			case "KIOSK":
				result = "getExportEmailKioskSummaryReport";
				break;
			case "CBDC":
				result = "getExportEmailCbdcSummaryReport";
				break;
			case "YONO 2.0":
				result = "getExportEmailYn20SummaryReport";
				break;
			case "CMPI":
				result = "getExportEmailCMPISummaryReport";
				break;
			default:
				result = "getExportEmailDefaultSummaryReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getEmailExportMaskedSummaryReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getExportMaskedEmailCardSummaryReport";
				break;
			case "PREPAID CARD":
				result = "getExportMaskedEmailPrepaidCardSummaryReport";
				break;
			case "RINB":
				result = "getExportMaskedEmailRinbSummaryReport";
				break;
			case "UPI":
				result = "getExportMaskedEmailUpiSummaryReport";
				break;
			case "YONO":
				result = "getExportMaskedEmailYonoSummaryReport";
				break;
			case "YONO LITE":
				result = "getExportMaskedEmailYonoLiteSummaryReport";
				break;
			case "FASTag":
				result = "getExportMaskedEmailFastTagSummaryReport";
				break;
			case "CINB":
				result = "getExportMaskedEmailCinbSummaryReport";
				break;
			case "KIOSK":
				result = "getExportMaskedEmailKioskSummaryReport";
				break;
			case "CBDC":
				result = "getExportMaskedEmailCbdcSummaryReport";
				break;
			case "YONO 2.0":
				result = "getExportMaskedEmailYn20SummaryReport";
				break;
			case "CMPI":
				result = "getExportMaskedEmailCMPISummaryReport";
				break;
			default:
				result = "getExportMaskedEmailDefaultSummaryReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getEmailArExportSummaryReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArExportEmailCardSummaryReport";
				break;
			case "PREPAID CARD":
				result = "getArExportEmailPrepaidCardSummaryReport";
				break;
			case "RINB":
				result = "getArExportEmailRinbSummaryReport";
				break;
			case "UPI":
				result = "getArExportEmailUpiSummaryReport";
				break;
			case "YONO":
				result = "getArExportEmailYonoSummaryReport";
				break;
			case "YONO LITE":
				result = "getArExportEmailYonoLiteSummaryReport";
				break;
			case "FASTag":
				result = "getArExportEmailFastTagSummaryReport";
				break;
			case "CINB":
				result = "getArExportEmailCinbSummaryReport";
				break;
			case "KIOSK":
				result = "getArExportEmailKioskSummaryReport";
				break;
			case "CBDC":
				result = "getArExportEmailCbdcSummaryReport";
				break;
			case "YONO 2.0":
				result = "getArExportEmailYn20SummaryReport";
				break;
			case "CMPI":
				result = "getArExportEmailCMPISummaryReport";
				break;
			default:
				result = "getArExportEmailDefaultSummaryReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getEmailArMaskedSummaryReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArExportMaskedEmailCardSummaryReport";
				break;
			case "PREPAID CARD":
				result = "getArExportMaskedEmailPrepaidCardSummaryReport";
				break;
			case "RINB":
				result = "getArExportMaskedEmailRinbSummaryReport";
				break;
			case "UPI":
				result = "getArExportMaskedEmailUpiSummaryReport";
				break;
			case "YONO":
				result = "getArExportMaskedEmailYonoSummaryReport";
				break;
			case "YONO LITE":
				result = "getArExportMaskedEmailYonoLiteSummaryReport";
				break;
			case "FASTag":
				result = "getArExportMaskedEmailFastTagSummaryReport";
				break;
			case "CINB":
				result = "getArExportMaskedEmailCinbSummaryReport";
				break;
			case "KIOSK":
				result = "getArExportMaskedEmailKioskSummaryReport";
				break;
			case "CBDC":
				result = "getArExportMaskedEmailCbdcSummaryReport";
				break;
			case "YONO 2.0":
				result = "getArExportMaskedEmailYn20SummaryReport";
				break;
			case "CMPI":
				result = "getArExportMaskedEmailCMPISummaryReport";
				break;
			default:
				result = "getArExportMaskedEmailDefaultSummaryReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getSMSExportDetailReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getExportCardDetailReport";
				break;
			case "PREPAID CARD":
				result = "getExportPrepaidCardDetailReport";
				break;
			case "RINB":
				result = "getExportRinbDetailReport";
				break;
			case "UPI":
				result = "getExportUpiDetailReport";
				break;
			case "YONO":
				result = "getExportYonoDetailReport";
				break;
			case "YONO LITE":
				result = "getExportYonoLiteDetailReport";
				break;
			case "FASTag":
				result = "getExportFastTagDetailReport";
				break;
			case "CINB":
				result = "getExportCinbDetailReport";
				break;
			case "KIOSK":
				result = "getExportKioskDetailReport";
				break;
			case "CBDC":
				result = "getExportCbdcDetailReport";
				break;
			case "YONO 2.0":
				result = "getExportYn20DetailReport";
				break;
			case "CMPI":
				result = "getExportCMPIDetailReport";
				break;
			// New channels added
			case "UPFI":
				result = "getExportUPFIDetailReport";
				break;
			case "IMPC":
				result = "getExportIMPCDetailReport";
				break;
			case "NEFC":
				result = "getExportNEFCDetailReport";
				break;
			case "RTGC":
				result = "getExportRTGCDetailReport";
				break;
			default:
				result = "getExportDefaultDetailReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getSMSExportMaskedDetailReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getExportMaskedCardDetailReport";
				break;
			case "PREPAID CARD":
				result = "getExportMaskedPrepaidCardDetailReport";
				break;
			case "RINB":
				result = "getExportMaskedRinbDetailReport";
				break;
			case "UPI":
				result = "getExportMaskedUpiDetailReport";
				break;
			case "YONO":
				result = "getExportMaskedYonoDetailReport";
				break;
			case "YONO LITE":
				result = "getExportMaskedYonoLiteDetailReport";
				break;
			case "FASTag":
				result = "getExportMaskedFastTagDetailReport";
				break;
			case "CINB":
				result = "getExportMaskedCinbDetailReport";
				break;
			case "KIOSK":
				result = "getExportMaskedKioskDetailReport";
				break;
			case "CBDC":
				result = "getExportMaskedCbdcDetailReport";
				break;
			case "YONO 2.0":
				result = "getExportMaskedYn20DetailReport";
				break;
			case "CMPI":
				result = "getExportMaskedCMPIDetailReport";
				break;
			// New channels added
			case "UPFI":
				result = "getExportMaskedUPFIDetailReport";
				break;
			case "IMPC":
				result = "getExportMaskedIMPCDetailReport";
				break;
			case "NEFC":
				result = "getExportMaskedNEFCDetailReport";
				break;
			case "RTGC":
				result = "getExportMaskedRTGCDetailReport";
				break;
			default:
				result = "getExportMaskedDefaultDetailReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getSMSArExportDetailReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArExportCardDetailReport";
				break;
			case "PREPAID CARD":
				result = "getArExportPrepaidCardDetailReport";
				break;
			case "RINB":
				result = "getArExportRinbDetailReport";
				break;
			case "UPI":
				result = "getArExportUpiDetailReport";
				break;
			case "YONO":
				result = "getArExportYonoDetailReport";
				break;
			case "YONO LITE":
				result = "getArExportYonoLiteDetailReport";
				break;
			case "FASTag":
				result = "getArExportFastTagDetailReport";
				break;
			case "CINB":
				result = "getArExportCinbDetailReport";
				break;
			case "KIOSK":
				result = "getArExportKioskDetailReport";
				break;
			case "CBDC":
				result = "getArExportCbdcDetailReport";
				break;
			case "YONO 2.0":
				result = "getArExportYn20DetailReport";
				break;
			case "CMPI":
				result = "getArExportCMPIDetailReport";
				break;
			// New Channels added
			case "UPFI":
				result = "getArExportUPFIDetailReport";
				break;
			case "IMPC":
				result = "getArExportIMPCDetailReport";
				break;
			case "NEFC":
				result = "getArExportNEFCDetailReport";
				break;
			case "RTGC":
				result = "getArExportRTGCDetailReport";
				break;
			default:
				result = "getArExportDefaultDetailReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getSMSArExportMaskedDetailReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArExportMaskedCardDetailReport";
				break;
			case "PREPAID CARD":
				result = "getArExportMaskedPrepaidCardDetailReport";
				break;
			case "RINB":
				result = "getArExportMaskedRinbDetailReport";
				break;
			case "UPI":
				result = "getArExportMaskedUpiDetailReport";
				break;
			case "YONO":
				result = "getArExportMaskedYonoDetailReport";
				break;
			case "YONO LITE":
				result = "getArExportMaskedYonoLiteDetailReport";
				break;
			case "FASTag":
				result = "getArExportMaskedFastTagDetailReport";
				break;
			case "CINB":
				result = "getArExportMaskedCinbDetailReport";
				break;
			case "KIOSK":
				result = "getArExportMaskedKioskDetailReport";
				break;
			case "CBDC":
				result = "getArExportMaskedCbdcDetailReport";
				break;
			case "YONO 2.0":
				result = "getArExportMaskedYn20DetailReport";
				break;
			case "CMPI":
				result = "getArExportMaskedCMPIDetailReport";
				break;
			// New channels added
			case "UPFI":
				result = "getArExportMaskedUPFIDetailReport";
				break;
			case "IMPC":
				result = "getArExportMaskedIMPCDetailReport";
				break;
			case "NEFC":
				result = "getArExportMaskedNEFCDetailReport";
				break;
			case "RTGC":
				result = "getArExportMaskedRTGCDetailReport";
				break;
			default:
				result = "getArExportMaskedDefaultDetailReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getEmailExportDetailReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getExportEmailCardDetailReport";
				break;
			case "PREPAID CARD":
				result = "getExportEmailPrepaidCardDetailReport";
				break;
			case "RINB":
				result = "getExportEmailRinbDetailReport";
				break;
			case "UPI":
				result = "getExportEmailUpiDetailReport";
				break;
			case "YONO":
				result = "getExportEmailYonoDetailReport";
				break;
			case "YONO LITE":
				result = "getExportEmailYonoLiteDetailReport";
				break;
			case "FASTag":
				result = "getExportEmailFastTagDetailReport";
				break;
			case "CINB":
				result = "getExportEmailCinbDetailReport";
				break;
			case "KIOSK":
				result = "getExportEmailKioskDetailReport";
				break;
			case "CBDC":
				result = "getExportEmailCbdcDetailReport";
				break;
			case "YONO 2.0":
				result = "getExportEmailYn20DetailReport";
				break;
			case "CMPI":
				result = "getExportEmailCMPIDetailReport";
				break;
			default:
				result = "getExportEmailDefaultDetailReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getEmailExportMaskedDetailReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getExportMaskedEmailCardDetailReport";
				break;
			case "PREPAID CARD":
				result = "getExportMaskedEmailPrepaidCardDetailReport";
				break;
			case "RINB":
				result = "getExportMaskedEmailRinbDetailReport";
				break;
			case "UPI":
				result = "getExportMaskedEmailUpiDetailReport";
				break;
			case "YONO":
				result = "getExportMaskedEmailYonoDetailReport";
				break;
			case "YONO LITE":
				result = "getExportMaskedEmailYonoLiteDetailReport";
				break;
			case "FASTag":
				result = "getExportMaskedEmailFastTagDetailReport";
				break;
			case "CINB":
				result = "getExportMaskedEmailCinbDetailReport";
				break;
			case "KIOSK":
				result = "getExportMaskedEmailKioskDetailReport";
				break;
			case "CBDC":
				result = "getExportMaskedEmailCbdcDetailReport";
				break;
			case "YONO 2.0":
				result = "getExportMaskedEmailYn20DetailReport";
				break;
			case "CMPI":
				result = "getExportMaskedEmailCMPIDetailReport";
				break;
			default:
				result = "getExportMaskedEmailDefaultDetailReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getEmailArExportDetailReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArExportEmailCardDetailReport";
				break;
			case "PREPAID CARD":
				result = "getArExportEmailPrepaidCardDetailReport";
				break;
			case "RINB":
				result = "getArExportEmailRinbDetailReport";
				break;
			case "UPI":
				result = "getArExportEmailUpiDetailReport";
				break;
			case "YONO":
				result = "getArExportEmailYonoDetailReport";
				break;
			case "YONO LITE":
				result = "getArExportEmailYonoLiteDetailReport";
				break;
			case "FASTag":
				result = "getArExportEmailFastTagDetailReport";
				break;
			case "CINB":
				result = "getArExportEmailCinbDetailReport";
				break;
			case "KIOSK":
				result = "getArExportEmailKioskDetailReport";
				break;
			case "CBDC":
				result = "getArExportEmailCbdcDetailReport";
				break;
			case "YONO 2.0":
				result = "getArExportEmailYn20DetailReport";
				break;
			case "CMPI":
				result = "getArExportEmailCMPIDetailReport";
				break;
			default:
				result = "getArExportEmailDefaultDetailReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getEmailArExportMaskedDetailReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArExportMaskedEmailCardDetailReport";
				break;
			case "PREPAID CARD":
				result = "getArExportMaskedEmailPrepaidCardDetailReport";
				break;
			case "RINB":
				result = "getArExportMaskedEmailRinbDetailReport";
				break;
			case "UPI":
				result = "getArExportMaskedEmailUpiDetailReport";
				break;
			case "YONO":
				result = "getArExportMaskedEmailYonoDetailReport";
				break;
			case "YONO LITE":
				result = "getArExportMaskedEmailYonoLiteDetailReport";
				break;
			case "FASTag":
				result = "getArExportMaskedEmailFastTagDetailReport";
				break;
			case "CINB":
				result = "getArExportMaskedEmailCinbDetailReport";
				break;
			case "KIOSK":
				result = "getArExportMaskedEmailKioskDetailReport";
				break;
			case "CBDC":
				result = "getArExportMaskedEmailCbdcDetailReport";
				break;
			case "YONO 2.0":
				result = "getArExportMaskedEmailYn20DetailReport";
				break;
			case "CMPI":
				result = "getArExportMaskedEmailCMPIDetailReport";
				break;
			default:
				result = "getArExportMaskedEmailDefaultDetailReport";
				break;
		}
		return result;
	}

}
