package com.concerto.prm.csm.report.dao;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aciworldwide.rms.ar.addins.dataaccess.prm.BasePrmDaoJdbcImpl;
import com.aciworldwide.rms.ar.grid.common.model.DataGridRequestModel;
import com.aciworldwide.rms.ar.grid.common.model.GridModel;
import com.aciworldwide.rms.ar.search.api.model.BetweenSearchGroup;
import com.aciworldwide.rms.ar.search.api.model.SimpleSearchGroup;
import com.concerto.prm.aop.ExecutionTimeLogger;
import com.concerto.prm.common.GridModelHandler;
import com.concerto.prm.common.GridModelHandlerPagination;
import com.concerto.prm.common.BaseReportsPrmDaoJdbcImpl;
import com.concerto.prm.util.DateTimeUtils;

@Service
public class CommonReportDao extends BasePrmDaoJdbcImpl {

	@Autowired
	private CommonSqlQueryDao commonSqlQueryDao;
	@Autowired
	BaseReportsPrmDaoJdbcImpl baseReportsPrmDaoJdbcImpl;

	public static final String APPLICATIN_LOGGER = "AppLogger";
	public static Logger logger = LoggerFactory.getLogger(APPLICATIN_LOGGER);

	private DateTimeUtils dateTimeUtils = new DateTimeUtils();

	@Override
	protected String getSqlBase() {
		return "Entity";
	}

	@ExecutionTimeLogger
	private Map<String, String> getDetailProperty(DataGridRequestModel dataRequestModel) {
		Map<String, String> DetailProperty = new HashMap<String, String>();

		if (dataRequestModel.getGridName().equals("sms-report-summary")
				|| dataRequestModel.getGridName().equals("email-report-summary")) {

			DetailProperty.put("RULE_ID", "ruleId");
			DetailProperty.put("RULE_NAME", "ruleName");
			DetailProperty.put("USER_NAME", "username");
			DetailProperty.put("REQUESTED_DATE", "requestedDate");
			DetailProperty.put("COUNT", "count");

		} else if (dataRequestModel.getGridName().equals("sms-report-detail")) {

			DetailProperty.put("ID", "id");
			DetailProperty.put("RULE_ID", "ruleId");
			DetailProperty.put("RULE_NAME", "ruleName");
			DetailProperty.put("USER_NAME", "username");
			DetailProperty.put("SMS_STATUS", "smsStatus");
			DetailProperty.put("SMS_SUBMISSION_DATE", "smsSubmissionDate");
			DetailProperty.put("SMS_DELIVERED_DATE", "smsDeliveredDate");
			DetailProperty.put("DIMENSION_ID", "dimesionId");
			DetailProperty.put("PHONE_NUMBER", "phoneNumber");
			DetailProperty.put("DD_PARTITION_DATE", "ddPartitionDate");
			DetailProperty.put("REQUESTED_DATE", "requestedDate");

		} else if (dataRequestModel.getGridName().equals("email-report-detail")) {

			DetailProperty.put("ID", "id");
			DetailProperty.put("RULE_ID", "ruleId");
			DetailProperty.put("RULE_NAME", "ruleName");
			DetailProperty.put("USER_NAME", "username");
			DetailProperty.put("EMAIL_STATUS", "emailStatus");
			DetailProperty.put("EMAIL_SUBMISSION_DATE", "emailSubmissionDate");
			DetailProperty.put("EMAIL_DELIVERED_DATE", "emailDeliveredDate");
			DetailProperty.put("DIMENSION_ID", "dimesionId");
			DetailProperty.put("TO_EMAIL", "toEmail");
			DetailProperty.put("CC_EMAIL", "ccEmail");
			DetailProperty.put("DD_PARTITION_DATE", "ddPartitionDate");
			DetailProperty.put("REQUESTED_DATE", "requestedDate");

		} else if (dataRequestModel.getGridName().equals("full-action-report-summary")) {

			DetailProperty.put("TXN_DATE", "TXN_DATE");
			DetailProperty.put("ALERT_DATE", "ALERT_DATE");
			DetailProperty.put("ACTION_DATE_TIME", "ACTION_DATE_TIME");
			DetailProperty.put("ACTION_LEVEL_KEY", "ACTION_LEVEL_KEY");
			DetailProperty.put("ACCOUNT_NUMBER", "ACCOUNT_NUMBER");
			DetailProperty.put("CHANNEL_TYPE", "CHANNEL_TYPE");
			DetailProperty.put("ACTION_TYPE", "ACTION_TYPE");
			DetailProperty.put("ACTION_NAME", "ACTION_NAME");
			DetailProperty.put("REVIEWER_ID", "REVIEWER_ID");
			DetailProperty.put("REVIEWER", "REVIEWER");
			DetailProperty.put("REVIEWER_NAME", "REVIEWER_NAME");
			DetailProperty.put("RULE_ID", "RULE_ID");
			DetailProperty.put("SUB_ACT_TYPE_ID", "SUB_ACT_TYPE_ID");

		} else if (dataRequestModel.getGridName().equals("mark-block-report-summary")) {

			DetailProperty.put("ALERT_DATE", "ALERT_DATE");
			DetailProperty.put("ACCOUNT_NO", "ACCOUNT_NO");
			DetailProperty.put("CUSTOMER_NAME", "CUSTOMER_NAME");
			DetailProperty.put("BRANCH_CODE", "BRANCH_CODE");
			DetailProperty.put("TXN_AMOUNT", "TXN_AMOUNT");
			DetailProperty.put("CIRCLE", "CODE_DESC");
			DetailProperty.put("MODULE", "MODULE_CODE");
			DetailProperty.put("NETWORK", "NETWORK_CODE");
			DetailProperty.put("REGION", "REGION_CODE");
			DetailProperty.put("ANALYST", "ANALYST_NAME");

		}
		return DetailProperty;
	}

	@ExecutionTimeLogger
	public GridModel getDefaultSummaryGrid(DataGridRequestModel dataRequestModel, String viewName) {
		String statement = this.getSqlStatementHelper().getSqlStatement("getDefaultSummaryReport");
		GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));
		//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle);
		return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle);
	}

	@ExecutionTimeLogger
	public GridModel getDefaultDetailGrid(DataGridRequestModel dataRequestModel, String viewName) {
		if (viewName.equalsIgnoreCase("sms-report-detail")) {
			String statement = this.getSqlStatementHelper().getSqlStatement("getSMSDefaultDetailReport");
			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));
			//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle);
		} else if (viewName.equalsIgnoreCase("email-report-detail")) {
			String statement = this.getSqlStatementHelper().getSqlStatement("getEmailDefaultDetailReport");
			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));
			//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle);
		} else if (viewName.equalsIgnoreCase("full-action-report-summary")) {
			String statement = this.getSqlStatementHelper().getSqlStatement("getFullActionDefaultGrid");
			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));
			//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle);
		} else if (viewName.equalsIgnoreCase("mark-block-report-summary")) {
			String statement = this.getSqlStatementHelper().getSqlStatement("getMarkBlockDefaultGrid");
			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));
			//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle);
		}
		return new GridModel();
	}

	// To fetch all Active SMS/Email/Mark & Block Channel Name
	@ExecutionTimeLogger
	public List<String> getChannelName(String viewName) {

		if (viewName.equalsIgnoreCase("SMS") || viewName.equalsIgnoreCase("EMAIL")) {

			String statement = this.getSqlStatementHelper().getSqlStatement("getReportChannelName");
			//List<Map<String, Object>> queryResult = getNRTSimpleJdbcOperations().queryForList(statement,"%" + viewName + "%");
			List<Map<String, Object>> queryResult = baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().queryForList(statement,"%" + viewName + "%");

			List<String> channelList = new ArrayList<String>();

			for (Map<String, Object> map : queryResult) {
				String value = (String) map.values().stream().findFirst().orElse("");
				channelList.add(value);
			}
			return channelList;

		} else if (viewName.equalsIgnoreCase("mark-block-report-summary")) {
			String statement = this.getSqlStatementHelper().getSqlStatement("getMarkBlockChannelName");
			//return getNRTSimpleJdbcOperations().queryForList(statement, String.class);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().queryForList(statement, String.class);
		} else {
			return null;
		}

	}

	// SUMMARY report all channel handle
	@ExecutionTimeLogger
	public GridModel getReportSummaryGroupGrid(DataGridRequestModel dataRequestModel, String viewName) {

		List<BetweenSearchGroup> betweenSearchGroups = dataRequestModel.getSearchRequestModel()
				.getBetweenSearchGroups();

		List<SimpleSearchGroup> simpleSearchGroups = dataRequestModel.getSearchRequestModel().getSimpleSearchGroup();

		String viewname = null;
		String cntViewName = null;

		String table = simpleSearchGroups.get(0).getValue().toString();

		String startDate = dateTimeUtils
				.unixToDateFormat(Long.parseLong(betweenSearchGroups.get(0).getStartValue().toString()));
		String endDate = dateTimeUtils
				.unixToDateFormat(Long.parseLong(betweenSearchGroups.get(0).getEndValue().toString()));

		long epochDate = Instant.now().toEpochMilli();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedDtm = Instant.ofEpochMilli(epochDate).atZone(ZoneId.of("Asia/Calcutta")).format(formatter);

		if (viewName.equalsIgnoreCase("sms-report-summary")) {

			if (startDate.equals(formattedDtm) && endDate.equals(formattedDtm)) {
				viewname = commonSqlQueryDao.getSMSMaskedSummaryReport(table.toString());
				cntViewName = commonSqlQueryDao.getSMSSummaryReportCount(table.toString());
			} else {
				viewname = commonSqlQueryDao.getSMSMaskedArSummaryReport(table.toString());
				cntViewName = commonSqlQueryDao.getSMSArSummaryReportCount(table.toString());
			}

			String statement = this.getSqlStatementHelper().getSqlStatement(viewname);

			int pageTotal = getCount(cntViewName, startDate, endDate);
			int pageNo = dataRequestModel.getPagination().getPageIndex();
			int pageSize = dataRequestModel.getPagination().getPageSize();

			GridModelHandlerPagination handlerPagination = new GridModelHandlerPagination(pageTotal,
					getDetailProperty(dataRequestModel));

			//return getNRTSimpleJdbcOperations().query(statement, handlerPagination::handle, startDate, endDate, pageNo,pageSize, pageSize);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, handlerPagination::handle, startDate, endDate, pageNo, pageSize, pageSize);

		} else if (viewName.equalsIgnoreCase("email-report-summary")) {
			if (startDate.equals(formattedDtm) && endDate.equals(formattedDtm)) {
				viewname = commonSqlQueryDao.getEmailSummaryReport(table.toString());
				cntViewName = commonSqlQueryDao.getEmailSummaryReportCount(table.toString());
			} else {
				viewname = commonSqlQueryDao.getEmailArSummaryReport(table.toString());
				cntViewName = commonSqlQueryDao.getEmailArSummaryReportCount(table.toString());

            }
//                logger.info("view name" +viewname);
//            logger.info("cntViewName" +cntViewName);
			String statement = this.getSqlStatementHelper().getSqlStatement(viewname);

			int pageTotal = getCount(cntViewName, startDate, endDate);
			int pageNo = dataRequestModel.getPagination().getPageIndex();
			int pageSize = dataRequestModel.getPagination().getPageSize();

//            logger.info("pageTotal" +pageTotal);
//            logger.info("pageNo" +pageNo);
//            logger.info("pageSize" +pageSize);
			GridModelHandlerPagination handlerPagination = new GridModelHandlerPagination(pageTotal,
					getDetailProperty(dataRequestModel));

			//return getNRTSimpleJdbcOperations().query(statement, handlerPagination::handle, startDate, endDate, pageNo, pageSize, pageSize);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, handlerPagination::handle, startDate, endDate, pageNo, pageSize, pageSize);
		}
		return new GridModel();
	}

	// DETAIL report all channel handle
	@ExecutionTimeLogger
	public GridModel getReportDetailGroupGrid(DataGridRequestModel dataRequestModel, String viewName) {

		List<BetweenSearchGroup> betweenSearchGroups = dataRequestModel.getSearchRequestModel()
				.getBetweenSearchGroups();

		List<SimpleSearchGroup> simpleSearchGroups = dataRequestModel.getSearchRequestModel().getSimpleSearchGroup();

		String viewname = null;
		String cntViewName = null;

		String table = simpleSearchGroups.get(0).getValue().toString();

		String startDate = dateTimeUtils
				.unixToDateFormat(Long.parseLong(betweenSearchGroups.get(0).getStartValue().toString()));
		String endDate = dateTimeUtils
				.unixToDateFormat(Long.parseLong(betweenSearchGroups.get(0).getEndValue().toString()));

		long epochDate = Instant.now().toEpochMilli();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedDtm = Instant.ofEpochMilli(epochDate).atZone(ZoneId.of("Asia/Calcutta")).format(formatter);

		if (viewName.equalsIgnoreCase("sms-report-detail")) {

			if (startDate.equals(formattedDtm) && endDate.equals(formattedDtm)) {
				viewname = commonSqlQueryDao.getSMSMaskedDetailReport(table);
				cntViewName = commonSqlQueryDao.getSMSDetailReportCount(table);
			} else {
				viewname = commonSqlQueryDao.getSMSArMaskedDetailReport(table);
				cntViewName = commonSqlQueryDao.getSMSArDetailReportCount(table);
			}

			String statement = this.getSqlStatementHelper().getSqlStatement(viewname);

			int pageTotal = getCount(cntViewName, startDate, endDate);
			int pageNo = dataRequestModel.getPagination().getPageIndex();
			int pageSize = dataRequestModel.getPagination().getPageSize();

			GridModelHandlerPagination handlerPagination = new GridModelHandlerPagination(pageTotal,
					getDetailProperty(dataRequestModel));
			//return getNRTSimpleJdbcOperations().query(statement, handlerPagination::handle, startDate, endDate, pageNo,	pageSize, pageSize);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, handlerPagination::handle, startDate, endDate, pageNo,	pageSize, pageSize);
		} else if (viewName.equalsIgnoreCase("email-report-detail")) {
			if (startDate.equals(formattedDtm) && endDate.equals(formattedDtm)) {
				viewname = commonSqlQueryDao.getEmailMaskedDetailReport(table);
				cntViewName = commonSqlQueryDao.getEmailDetailReportCount(table);
			} else {
				viewname = commonSqlQueryDao.getEmailArMaskedDetailReport(table);
				cntViewName = commonSqlQueryDao.getEmailArDetailReportCount(table);
			}

			String statement = this.getSqlStatementHelper().getSqlStatement(viewname);

			int pageTotal = getCount(cntViewName, startDate, endDate);
			int pageNo = dataRequestModel.getPagination().getPageIndex();
			int pageSize = dataRequestModel.getPagination().getPageSize();

			GridModelHandlerPagination handlerPagination = new GridModelHandlerPagination(pageTotal,
					getDetailProperty(dataRequestModel));
			//return getNRTSimpleJdbcOperations().query(statement, handlerPagination::handle, startDate, endDate, pageNo,	pageSize, pageSize);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, handlerPagination::handle, startDate, endDate, pageNo,	pageSize, pageSize);

		} else if (viewName.equalsIgnoreCase("full-action-report-summary")) {
			cntViewName = "getFullActionReportCount";

			String statement = this.getSqlStatementHelper().getSqlStatement("getFullActionReport");

			int pageTotal = getCount(cntViewName, startDate, endDate);
			int pageNo = dataRequestModel.getPagination().getPageIndex();
			int pageSize = dataRequestModel.getPagination().getPageSize();
			GridModelHandlerPagination handlerPagination = new GridModelHandlerPagination(pageTotal,
					getDetailProperty(dataRequestModel));

			//return getNRTSimpleJdbcOperations().query(statement, handlerPagination::handle, startDate, endDate, pageNo, pageSize, pageSize);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, handlerPagination::handle, startDate, endDate, pageNo,
					pageSize, pageSize);

		} else if (viewName.equalsIgnoreCase("mark-block-report-summary")) {

			String action = simpleSearchGroups.get(1).getValue().toString();

			if (action.equalsIgnoreCase("MARK")) {
				viewname = "getMarkAndBlockActionReport";
				cntViewName = "getMarkAndBlockActionReportCount";
			} else if (action.equalsIgnoreCase("BLOCK")) {
				viewname = "getMarkAndBlockActionReport";
				cntViewName = "getMarkAndBlockActionReportCount";
			} else {
				viewname = "getMarkAndBlockActionReportBoth";
				cntViewName = "getMarkAndBlockActionReportCountBoth";
			}

			String statement = this.getSqlStatementHelper().getSqlStatement(viewname);

			if (action.equalsIgnoreCase("MARK") || action.equalsIgnoreCase("BLOCK")) {
				int pageTotal = getCountMBR(cntViewName, startDate, endDate, action.toString(), table);
				int pageNo = dataRequestModel.getPagination().getPageIndex();
				int pageSize = dataRequestModel.getPagination().getPageSize();

				GridModelHandlerPagination handlerPagination = new GridModelHandlerPagination(pageTotal,
						getDetailProperty(dataRequestModel));

				//return getNRTSimpleJdbcOperations().query(statement, handlerPagination::handle, startDate, endDate, action, table, pageNo, pageSize, pageSize);
				return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, handlerPagination::handle, startDate, endDate, action, table, pageNo, pageSize, pageSize);
			} else {
				int pageTotal = getCountBothMBR(cntViewName, startDate, endDate, table);
				int pageNo = dataRequestModel.getPagination().getPageIndex();
				int pageSize = dataRequestModel.getPagination().getPageSize();

				GridModelHandlerPagination handlerPagination = new GridModelHandlerPagination(pageTotal,
						getDetailProperty(dataRequestModel));

				//return getNRTSimpleJdbcOperations().query(statement, handlerPagination::handle, startDate, endDate, table, pageNo, pageSize, pageSize);
				return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, handlerPagination::handle, startDate, endDate, table, pageNo, pageSize, pageSize);
			}
		}
		return new GridModel();
	}

	// Pagination Count
	@ExecutionTimeLogger
	private int getCount(String viewname, String startDate, String endDate) {
		String statement = this.getSqlStatementHelper().getSqlStatement(viewname);
		//return getNRTSimpleJdbcOperations().queryForObject(statement, Integer.class, startDate, endDate);
		return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().queryForObject(statement, Integer.class, startDate, endDate);
	}

	@ExecutionTimeLogger
	private int getCountMBR(String viewname, String startDate, String endDate, String action, String table) {
		String statement = this.getSqlStatementHelper().getSqlStatement("getMarkAndBlockActionReportCount");
		//return getNRTSimpleJdbcOperations().queryForObject(statement, Integer.class, startDate, endDate, action, table);
		return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().queryForObject(statement, Integer.class, startDate, endDate, action, table);
	}

	@ExecutionTimeLogger
	private int getCountBothMBR(String viewname, String startDate, String endDate, String table) {
		String statement = this.getSqlStatementHelper().getSqlStatement("getMarkAndBlockActionReportCountBoth");
		//return getNRTSimpleJdbcOperations().queryForObject(statement, Integer.class, startDate, endDate, table);
		return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().queryForObject(statement, Integer.class, startDate, endDate, table);
	}
}