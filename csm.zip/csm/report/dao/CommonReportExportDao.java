package com.concerto.prm.csm.report.dao;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import com.concerto.prm.common.BaseReportsPrmDaoJdbcImpl;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.mutable.MutableInt;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.aciworldwide.rms.ar.addins.dataaccess.prm.BasePrmDaoJdbcImpl;
import com.aciworldwide.rms.ar.grid.common.model.ExportDataGridRequestModel;
import com.aciworldwide.rms.ar.grid.common.model.FieldValue;
import com.aciworldwide.rms.ar.grid.common.model.GridModel;
import com.aciworldwide.rms.ar.search.api.model.BetweenSearchGroup;
import com.aciworldwide.rms.ar.search.api.model.SimpleSearchGroup;
import com.concerto.prm.CsmBackendApplication;
import com.concerto.prm.aop.ExecutionTimeLogger;
import com.concerto.prm.common.GridModelHandler;
import com.concerto.prm.eb.report.dao.HeaderFooterPageEvent;
import com.concerto.prm.util.DateTimeUtils;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfStream;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class CommonReportExportDao extends BasePrmDaoJdbcImpl {

	public static Logger logger = LoggerFactory.getLogger(CsmBackendApplication.APPLICATIN_LOGGER);

	private DateTimeUtils dateTimeUtils = new DateTimeUtils();

	@Autowired
	private CommonExportSqlQueryDao commonExportSqlQueryDao;

	@Autowired
	BaseReportsPrmDaoJdbcImpl baseReportsPrmDaoJdbcImpl;

	@Override
	protected String getSqlBase() {
		return "Entity";
	}

	@Value("${export.chunks.pdf}")
	private int pdfexportChunks;

	@Value("${export.genericDatalimit}")
	private int genericDatalimit;

	@Value("${export.genericErrorMessage}")
	private String genericErrorMessage;

	@ExecutionTimeLogger
	private Map<String, Integer> getHeaderIndex(ExportDataGridRequestModel dataRequestModel) {

		Map<String, Integer> headersIndex = new HashMap<String, Integer>();

		if (dataRequestModel.getGridName().equals("sms-report-summary")
				|| dataRequestModel.getGridName().equals("email-report-summary")) {

			headersIndex.put("RULE_ID", 0);
			headersIndex.put("RULE_NAME", 1);
			headersIndex.put("USER_NAME", 2);
			headersIndex.put("REQUESTED_DATE", 3);
			headersIndex.put("COUNT", 4);

		} else if (dataRequestModel.getGridName().equals("sms-report-detail")) {

			headersIndex.put("ID", 0);
			headersIndex.put("RULE_ID", 1);
			headersIndex.put("RULE_NAME", 2);
			headersIndex.put("USER_NAME", 3);
			headersIndex.put("REQUESTED_DATE", 4);
			headersIndex.put("DD_PARTITION_DATE", 5);
			headersIndex.put("SMS_STATUS", 6);
			headersIndex.put("SMS_SUBMISSION_DATE", 7);
			headersIndex.put("SMS_DELIVERED_DATE", 8);
			headersIndex.put("DIMENSION_ID", 9);
			headersIndex.put("PHONE_NUMBER", 10);

		} else if (dataRequestModel.getGridName().equals("email-report-detail")) {

			headersIndex.put("ID", 0);
			headersIndex.put("RULE_ID", 1);
			headersIndex.put("RULE_NAME", 2);
			headersIndex.put("USER_NAME", 3);
			headersIndex.put("REQUESTED_DATE", 4);
			headersIndex.put("DD_PARTITION_DATE", 5);
			headersIndex.put("EMAIL_STATUS", 6);
			headersIndex.put("EMAIL_SUBMISSION_DATE", 7);
			headersIndex.put("EMAIL_DELIVERED_DATE", 8);
			headersIndex.put("DIMENSION_ID", 9);
			headersIndex.put("TO_EMAIL", 10);
			headersIndex.put("CC_EMAIL", 11);

		} else if (dataRequestModel.getGridName().equals("full-action-report-summary")) {

			headersIndex.put("TXN_DATE", 0);
			headersIndex.put("ALERT_DATE", 1);
			headersIndex.put("ACTION_DATE_TIME", 2);
			headersIndex.put("ACTION_LEVEL_KEY", 3);
			headersIndex.put("ACCOUNT_NUMBER", 4);
			headersIndex.put("CHANNEL_TYPE", 5);
			headersIndex.put("ACTION_TYPE", 6);
			headersIndex.put("ACTION_NAME", 7);
			headersIndex.put("REVIEWER_ID", 8);
			headersIndex.put("REVIEWER", 9);
			headersIndex.put("REVIEWER_NAME", 10);
			headersIndex.put("RULE_ID", 11);
			headersIndex.put("SUB_ACT_TYPE_ID", 12);

		} else if (dataRequestModel.getGridName().equals("mark-block-report-summary")) {

			headersIndex.put("ALERT_DATE", 0);
			headersIndex.put("ACCOUNT_NO", 1);
			headersIndex.put("CUSTOMER_NAME", 2);
			headersIndex.put("BRANCH_CODE", 3);
			headersIndex.put("TXN_AMOUNT", 4);
			headersIndex.put("CIRCLE", 5);
			headersIndex.put("MODULE", 6);
			headersIndex.put("NETWORK", 7);
			headersIndex.put("REGION", 8);
			headersIndex.put("ANALYST", 9);

		} else if(dataRequestModel.getGridName().equals("whitelist-data-report")) {
			
			headersIndex.put("TRANSACTION_DATE_TIME", 0);
			headersIndex.put("DIMENSION", 1);
			headersIndex.put("WHITELIST_ID", 2);
			headersIndex.put("WHITELIST_VALUE", 3);
			headersIndex.put("ANALYST", 4);
			headersIndex.put("WHITELIST_DATE", 5);
			headersIndex.put("RULE_WHITELISTED",6);
		}
		
		return headersIndex;
	}

	@ExecutionTimeLogger
	private Map<String, String> getDetailProperty(ExportDataGridRequestModel dataRequestModel) {

		Map<String, String> DetailProperty = new HashMap<String, String>();

		if (dataRequestModel.getGridName().equals("sms-report-summary")
				|| dataRequestModel.getGridName().equals("email-report-summary")) {

			DetailProperty.put("RULE_ID", "ruleId");
			DetailProperty.put("RULE_NAME", "ruleName");
			DetailProperty.put("USER_NAME", "username");
			DetailProperty.put("REQUESTED_DATE", "requestedDate");
			DetailProperty.put("COUNT", "count");

		} else if (dataRequestModel.getGridName().equals("sms-report-detail")) {

			DetailProperty.put("ID", "id");
			DetailProperty.put("RULE_ID", "ruleId");
			DetailProperty.put("RULE_NAME", "ruleName");
			DetailProperty.put("USER_NAME", "username");
			DetailProperty.put("SMS_STATUS", "smsStatus");
			DetailProperty.put("SMS_SUBMISSION_DATE", "smsSubmissionDate");
			DetailProperty.put("SMS_DELIVERED_DATE", "smsDeliveredDate");
			DetailProperty.put("DIMENSION_ID", "dimesionId");
			DetailProperty.put("PHONE_NUMBER", "phoneNumber");
			DetailProperty.put("DD_PARTITION_DATE", "ddPartitionDate");
			DetailProperty.put("REQUESTED_DATE", "requestedDate");

		} else if (dataRequestModel.getGridName().equals("email-report-detail")) {

			DetailProperty.put("ID", "id");
			DetailProperty.put("RULE_ID", "ruleId");
			DetailProperty.put("RULE_NAME", "ruleName");
			DetailProperty.put("USER_NAME", "username");
			DetailProperty.put("EMAIL_STATUS", "emailStatus");
			DetailProperty.put("EMAIL_SUBMISSION_DATE", "emailSubmissionDate");
			DetailProperty.put("EMAIL_DELIVERED_DATE", "emailDeliveredDate");
			DetailProperty.put("DIMENSION_ID", "dimesionId");
			DetailProperty.put("TO_EMAIL", "toEmail");
			DetailProperty.put("CC_EMAIL", "ccEmail");
			DetailProperty.put("DD_PARTITION_DATE", "ddPartitionDate");
			DetailProperty.put("REQUESTED_DATE", "requestedDate");

		} else if (dataRequestModel.getGridName().equals("full-action-report-summary")) {

			DetailProperty.put("TXN_DATE", "TXN_DATE");
			DetailProperty.put("ALERT_DATE", "ALERT_DATE");
			DetailProperty.put("ACTION_DATE_TIME", "ACTION_DATE_TIME");
			DetailProperty.put("ACTION_LEVEL_KEY", "ACTION_LEVEL_KEY");
			DetailProperty.put("ACCOUNT_NUMBER", "ACCOUNT_NUMBER");
			DetailProperty.put("CHANNEL_TYPE", "CHANNEL_TYPE");
			DetailProperty.put("ACTION_TYPE", "ACTION_TYPE");
			DetailProperty.put("ACTION_NAME", "ACTION_NAME");
			DetailProperty.put("REVIEWER_ID", "REVIEWER_ID");
			DetailProperty.put("REVIEWER", "REVIEWER");
			DetailProperty.put("REVIEWER_NAME", "REVIEWER_NAME");
			DetailProperty.put("RULE_ID", "RULE_ID");
			DetailProperty.put("SUB_ACT_TYPE_ID", "SUB_ACT_TYPE_ID");

		} else if (dataRequestModel.getGridName().equals("mark-block-report-summary")) {

			DetailProperty.put("ALERT_DATE", "ALERT_DATE");
			DetailProperty.put("ACCOUNT_NO", "ACCOUNT_NO");
			DetailProperty.put("CUSTOMER_NAME", "CUSTOMER_NAME");
			DetailProperty.put("BRANCH_CODE", "BRANCH_CODE");
			DetailProperty.put("TXN_AMOUNT", "TXN_AMOUNT");
			DetailProperty.put("CIRCLE", "CODE_DESC");
			DetailProperty.put("MODULE", "MODULE_CODE");
			DetailProperty.put("NETWORK", "NETWORK_CODE");
			DetailProperty.put("REGION", "REGION_CODE");
			DetailProperty.put("ANALYST", "ANALYST_NAME");

		} else if(dataRequestModel.getGridName().equals("whitelist-data-report")) {
			
			DetailProperty.put("TRANSACTION_DATE_TIME", "Transaction Date Time");
			DetailProperty.put("DIMENSION", "Dimension");
			DetailProperty.put("WHITELIST_ID", "Whitelist ID");
			DetailProperty.put("WHITELIST_VALUE", "Whitelisted Value");
			DetailProperty.put("ANALYST", "Analyst ID");
			DetailProperty.put("WHITELIST_DATE", "Whitelist Date");
			DetailProperty.put("RULE_WHITELISTED", "Rule Whitelisted");
			
		}
		return DetailProperty;
	}

	@ExecutionTimeLogger
	private Map<String, String> getDefaultHeaders(ExportDataGridRequestModel dataRequestModel) {

		Map<String, String> defaultHeaders = new HashMap<String, String>();

		if (dataRequestModel.getGridName().equals("sms-report-summary")
				|| dataRequestModel.getGridName().equals("email-report-summary")) {

			defaultHeaders.put("RULE_ID", "Rule ID");
			defaultHeaders.put("RULE_NAME", "Rule Name");
			defaultHeaders.put("USER_NAME", "User Name");
			defaultHeaders.put("REQUESTED_DATE", "Requested Date");
			defaultHeaders.put("COUNT", "Count");

		} else if (dataRequestModel.getGridName().equals("sms-report-detail")) {

			defaultHeaders.put("ID", "ID");
			defaultHeaders.put("RULE_ID", "Rule ID");
			defaultHeaders.put("RULE_NAME", "Rule Name");
			defaultHeaders.put("USER_NAME", "User Name");
			defaultHeaders.put("SMS_STATUS", "SMS Status");
			defaultHeaders.put("SMS_SUBMISSION_DATE", "SMS Submission Date");
			defaultHeaders.put("SMS_DELIVERED_DATE", "SMS Delivered Date");
			defaultHeaders.put("DIMENSION_ID", "Dimension ID");
			defaultHeaders.put("PHONE_NUMBER", "Phone Number");
			defaultHeaders.put("DD_PARTITION_DATE", "Partition Date");
			defaultHeaders.put("REQUESTED_DATE", "Requested Date");
			defaultHeaders.put("COUNT", "Count");

		} else if (dataRequestModel.getGridName().equals("email-report-detail")) {

			defaultHeaders.put("ID", "ID");
			defaultHeaders.put("RULE_ID", "Rule Id");
			defaultHeaders.put("RULE_NAME", "Rule Name");
			defaultHeaders.put("USER_NAME", "User Name");
			defaultHeaders.put("EMAIL_STATUS", "Email Status");
			defaultHeaders.put("EMAIL_SUBMISSION_DATE", "Email Submission Date");
			defaultHeaders.put("EMAIL_DELIVERED_DATE", "Email Delivered Date");
			defaultHeaders.put("DIMENSION_ID", "Dimesion Id");
			defaultHeaders.put("TO_EMAIL", "To Email");
			defaultHeaders.put("CC_EMAIL", "CC Email");
			defaultHeaders.put("DD_PARTITION_DATE", "Partition Date");
			defaultHeaders.put("REQUESTED_DATE", "Requested Date");
			defaultHeaders.put("COUNT", "Count");

		} else if (dataRequestModel.getGridName().equals("full-action-report-summary")) {

			defaultHeaders.put("TXN_DATE", "Transaction Date");
			defaultHeaders.put("ALERT_DATE", "Alert Date");
			defaultHeaders.put("ACTION_DATE_TIME", "Action Date");
			defaultHeaders.put("ACTION_LEVEL_KEY", "Dimension ID");
			defaultHeaders.put("ACCOUNT_NUMBER", "Account Number");
			defaultHeaders.put("CHANNEL_TYPE", "Channel Type");
			defaultHeaders.put("ACTION_TYPE", "Action Type");
			defaultHeaders.put("ACTION_NAME", "Action Name");
			defaultHeaders.put("REVIEWER_ID", "Reviewer ID");
			defaultHeaders.put("REVIEWER", "Reviewer");
			defaultHeaders.put("REVIEWER_NAME", "Reviewer Name");
			defaultHeaders.put("RULE_ID", "Rule Id");
			defaultHeaders.put("SUB_ACT_TYPE_ID", "Sub Action Type ID");

		} else if (dataRequestModel.getGridName().equals("mark-block-report-summary")) {

			defaultHeaders.put("ALERT_DATE", "Alert Date");
			defaultHeaders.put("ACCOUNT_NO", "Account Number");
			defaultHeaders.put("CUSTOMER_NAME", "Customer Name");
			defaultHeaders.put("BRANCH_CODE", "Branch Code");
			defaultHeaders.put("TXN_AMOUNT", "Transaction Amount");
			defaultHeaders.put("CIRCLE", "Code Description");
			defaultHeaders.put("MODULE", "Module Code");
			defaultHeaders.put("NETWORK", "Network Code");
			defaultHeaders.put("REGION", "Region Code");
			defaultHeaders.put("ANALYST", "Analyst Name");

		} else if(dataRequestModel.getGridName().equals("whitelist-data-report")) {
			
			defaultHeaders.put("TRANSACTION_DATE_TIME", "Transaction Date Time");
			defaultHeaders.put("DIMENSION", "Dimension");
			defaultHeaders.put("WHITELIST_ID", "Whitelist ID");
			defaultHeaders.put("WHITELIST_VALUE", "Whitelisted Value");
			defaultHeaders.put("ANALYST", "Analyst ID");
			defaultHeaders.put("WHITELIST_DATE", "Whitelist Date");
			defaultHeaders.put("RULE_WHITELISTED", "Rule Whitelisted");
			
		}
		
		return defaultHeaders;
	}

	@ExecutionTimeLogger
	public Object filterGrid(ExportDataGridRequestModel requestModel) {
		String viewName = requestModel.getViewName();

		if (viewName.equalsIgnoreCase("sms-report-detail") || viewName.equalsIgnoreCase("email-report-detail")) {
			return getDetailGrid(requestModel, viewName).getRowData();
		} else if (viewName.equalsIgnoreCase("full-action-report-summary")) {
			return getDetailGrid(requestModel, viewName).getRowData();
		} else if (viewName.equalsIgnoreCase("mark-block-report-summary")) {
			return getDetailGrid(requestModel, viewName).getRowData();
		} else if (viewName.equalsIgnoreCase("sms-report-summary")
				|| viewName.equalsIgnoreCase("email-report-summary")) {
			return getSummaryGrid(requestModel, viewName).getRowData();
		} else if ("whitelist-data-report".equalsIgnoreCase(viewName))  {
			return getDetailGrid(requestModel,viewName).getRowData();
		} else {
			return getSummaryGrid(requestModel, viewName).getRowData();
		}
	}

	@ExecutionTimeLogger
	public GridModel getSummaryGrid(ExportDataGridRequestModel dataRequestModel, String viewName) {

		if (dataRequestModel.getSearchRequestModel() == null) {
			return getDefaultSummaryGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() == null
				|| dataRequestModel.getSearchRequestModel().getSimpleSearchGroup() == null
						&& viewName.equalsIgnoreCase("sms-report-summary")) {
			return getDefaultSummaryGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel() != null
				&& viewName.equalsIgnoreCase("sms-report-summary")) {
			return getReportSummaryGroupGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() == null
				|| dataRequestModel.getSearchRequestModel().getSimpleSearchGroup() == null
						&& viewName.equalsIgnoreCase("email-report-summary")) {
			return getDefaultSummaryGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel() != null
				&& viewName.equalsIgnoreCase("email-report-summary")) {
			return getReportSummaryGroupGrid(dataRequestModel, viewName);
		} else {
			return getDefaultSummaryGrid(dataRequestModel, viewName);
		}

	}

	@ExecutionTimeLogger
	public GridModel getDetailGrid(ExportDataGridRequestModel dataRequestModel, String viewName) {

		if (dataRequestModel.getSearchRequestModel() == null) {
			return getDefaultDetailGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() == null
				&& viewName.equalsIgnoreCase("sms-report-detail")) {
			return getDefaultDetailGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() == null
				&& viewName.equalsIgnoreCase("email-report-detail")) {
			return getDefaultDetailGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() == null
				&& viewName.equalsIgnoreCase("full-action-report-summary")) {
			return getDefaultDetailGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() == null
				&& viewName.equalsIgnoreCase("mark-block-report-summary")) {
			return getDefaultDetailGrid(dataRequestModel, viewName);
		}  else if  (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() == null
				&& viewName.equalsIgnoreCase("whitelist-data-report")) {
			return getDefaultDetailGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() != null
				&& viewName.equalsIgnoreCase("email-report-detail")) {
			return getReportDetailGroupGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() != null
				&& viewName.equalsIgnoreCase("sms-report-detail")) {
			return getReportDetailGroupGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() != null
				&& viewName.equalsIgnoreCase("full-action-report-summary")) {
			return getReportDetailGroupGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() != null
				&& viewName.equalsIgnoreCase("mark-block-report-summary")) {
			return getReportDetailGroupGrid(dataRequestModel, viewName);
		}else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() != null
				&& viewName.equalsIgnoreCase("whitelist-data-report")) {
			return getReportDetailGroupGrid(dataRequestModel, viewName);
		} else {
			return getDefaultDetailGrid(dataRequestModel, viewName);
		}

	}

	@ExecutionTimeLogger
	public GridModel getDefaultSummaryGrid(ExportDataGridRequestModel dataRequestModel, String viewName) {
		String statement = this.getSqlStatementHelper().getSqlStatement("getDefaultSummaryReport");
		GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));
		//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle);
		return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle);
	}

	@ExecutionTimeLogger
	public GridModel getDefaultDetailGrid(ExportDataGridRequestModel dataRequestModel, String viewName) {
		if (viewName.equalsIgnoreCase("sms-report-detail")) {
			String statement = this.getSqlStatementHelper().getSqlStatement("getSMSDefaultDetailReport");
			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));
			//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle);
		} else if (viewName.equalsIgnoreCase("email-report-detail")) {
			String statement = this.getSqlStatementHelper().getSqlStatement("getEmailDefaultDetailReport");
			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));
			//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle);
		} else if (viewName.equalsIgnoreCase("full-action-report-summary")) {
			String statement = this.getSqlStatementHelper().getSqlStatement("getFullActionDefaultGrid");
			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));
			//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle);
		} else if (viewName.equalsIgnoreCase("mark-block-report-summary")) {
			String statement = this.getSqlStatementHelper().getSqlStatement("getMarkBlockDefaultGrid");
			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));
			//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle);
		} else if (viewName.equalsIgnoreCase("whitelist-data-report")) {
			String statement = this.getSqlStatementHelper().getSqlStatement("getWhitelistDataDefaultGrid");
			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle);
		}
		return new GridModel();
	}

	// SMS/EMAIL SUMMARY reports for all channel
	@ExecutionTimeLogger
	public GridModel getReportSummaryGroupGrid(ExportDataGridRequestModel dataRequestModel, String viewName) {
		List<BetweenSearchGroup> betweenSearchGroups = dataRequestModel.getSearchRequestModel()
				.getBetweenSearchGroups();
		List<SimpleSearchGroup> simpleSearchGroups = dataRequestModel.getSearchRequestModel().getSimpleSearchGroup();

		String viewname = null;
		String table = simpleSearchGroups.get(0).getValue().toString();

		String startDate = dateTimeUtils
				.unixToDateFormat(Long.parseLong(betweenSearchGroups.get(0).getStartValue().toString()));
		String endDate = dateTimeUtils
				.unixToDateFormat(Long.parseLong(betweenSearchGroups.get(0).getEndValue().toString()));

		Instant instant = Instant.now();
		long epochDate = instant.toEpochMilli();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedDtm = Instant.ofEpochMilli(epochDate).atZone(ZoneId.of("Asia/Calcutta")).format(formatter);

		if (viewName.equalsIgnoreCase("sms-report-summary")) {

			if (startDate.equals(formattedDtm) && endDate.equals(formattedDtm)) {
				if (dataRequestModel.isExportDataUnmasked()) {
					viewname = commonExportSqlQueryDao.getSMSExportSummaryReport(table.toString());
				} else {
					viewname = commonExportSqlQueryDao.getSMSExportMaskedSummaryReport(table.toString());
				}
			} else {
				if (dataRequestModel.isExportDataUnmasked()) {
					viewname = commonExportSqlQueryDao.getSMSArExportSummaryReport(table.toString());
				} else {
					viewname = commonExportSqlQueryDao.getSMSArExportMaskedSummaryReport(table.toString());
				}
			}

			String statement = this.getSqlStatementHelper().getSqlStatement(viewname);

			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));

			//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate);
		} else if (viewName.equalsIgnoreCase("email-report-summary")) {
			if (startDate.equals(formattedDtm) && endDate.equals(formattedDtm)) {
				if (dataRequestModel.isExportDataUnmasked()) {
					viewname = commonExportSqlQueryDao.getEmailExportSummaryReport(table.toString());
				} else {
					viewname = commonExportSqlQueryDao.getEmailExportMaskedSummaryReport(table.toString());
				}
			} else {
				if (dataRequestModel.isExportDataUnmasked()) {
					viewname = commonExportSqlQueryDao.getEmailArExportSummaryReport(table.toString());
				} else {
					viewname = commonExportSqlQueryDao.getEmailArMaskedSummaryReport(table.toString());
				}
			}

			String statement = this.getSqlStatementHelper().getSqlStatement(viewname);

			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));

			//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate);

		}
		return new GridModel();
	}

	// SMS/EMAIL/FULL AUTO ACTION/MARK & BLOCK DETAIL REPORT
	@ExecutionTimeLogger
	public GridModel getReportDetailGroupGrid(ExportDataGridRequestModel dataRequestModel, String viewName) {

		List<BetweenSearchGroup> betweenSearchGroups = dataRequestModel.getSearchRequestModel()
				.getBetweenSearchGroups();
		List<SimpleSearchGroup> simpleSearchGroups = dataRequestModel.getSearchRequestModel().getSimpleSearchGroup();

		String viewname;
		String table = !CollectionUtils.isEmpty(simpleSearchGroups) ? simpleSearchGroups.get(0).getValue().toString() : "";

		String startDate = dateTimeUtils
				.unixToDateFormat(Long.parseLong(betweenSearchGroups.get(0).getStartValue().toString()));
		String endDate = dateTimeUtils
				.unixToDateFormat(Long.parseLong(betweenSearchGroups.get(0).getEndValue().toString()));

		Instant instant = Instant.now();
		long epochDate = instant.toEpochMilli();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedDtm = Instant.ofEpochMilli(epochDate).atZone(ZoneId.of("Asia/Calcutta")).format(formatter);

		if (viewName.equalsIgnoreCase("sms-report-detail")) {

			if (startDate.equals(formattedDtm) && endDate.equals(formattedDtm)) {
				if (dataRequestModel.isExportDataUnmasked()) {
					viewname = commonExportSqlQueryDao.getSMSExportDetailReport(table.toString());
				} else {
					viewname = commonExportSqlQueryDao.getSMSExportMaskedDetailReport(table.toString());
				}
			} else {
				if (dataRequestModel.isExportDataUnmasked()) {
					viewname = commonExportSqlQueryDao.getSMSArExportDetailReport(table.toString());
				} else {
					viewname = commonExportSqlQueryDao.getSMSArExportMaskedDetailReport(table.toString());
				}
			}

			String statement = this.getSqlStatementHelper().getSqlStatement(viewname);

			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));

			//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate);

		} else if (viewName.equalsIgnoreCase("email-report-detail")) {
			if (startDate.equals(formattedDtm) && endDate.equals(formattedDtm)) {
				if (dataRequestModel.isExportDataUnmasked()) {
					viewname = commonExportSqlQueryDao.getEmailExportDetailReport(table.toString());
				} else {
					viewname = commonExportSqlQueryDao.getEmailExportMaskedDetailReport(table.toString());
				}
			} else {
				if (dataRequestModel.isExportDataUnmasked()) {
					viewname = commonExportSqlQueryDao.getEmailArExportDetailReport(table.toString());
				} else {
					viewname = commonExportSqlQueryDao.getEmailArExportMaskedDetailReport(table.toString());
				}
			}

			String statement = this.getSqlStatementHelper().getSqlStatement(viewname);

			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));

			//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate);

		} else if (viewName.equalsIgnoreCase("full-action-report-summary")) {
			if (dataRequestModel.isExportDataUnmasked()) {
				viewname = "getFullActionExportReport";
			} else {
				viewname = "getFullActionExportMaskedReport";
			}

			String statement = this.getSqlStatementHelper().getSqlStatement(viewname);

			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));

			//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate);
			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate);
		} else if (viewName.equalsIgnoreCase("mark-block-report-summary")) {
			String action = simpleSearchGroups.get(1).getValue().toString();

			if (dataRequestModel.isExportDataUnmasked()) {
				if (action.equalsIgnoreCase("MARK")) {
					viewname = "getMarkAndBlockActionExportReport";
				} else if (action.equalsIgnoreCase("BLOCK")) {
					viewname = "getMarkAndBlockActionExportReport";
				} else {
					viewname = "getMarkAndBlockActionExportReportBoth";
				}
			} else {
				if (action.equalsIgnoreCase("MARK")) {
					viewname = "getMarkAndBlockActionExportMaskedReport";
				} else if (action.equalsIgnoreCase("BLOCK")) {
					viewname = "getMarkAndBlockActionExportMaskedReport";
				} else {
					viewname = "getMarkAndBlockActionExportMaskedReportBoth";
				}
			}

			String statement = this.getSqlStatementHelper().getSqlStatement(viewname);

			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));

			if (action.equalsIgnoreCase("BLOCK") || action.equalsIgnoreCase("MARK")) {
				//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate, action, table);
				return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate, action, table);
			} else {
				//return getNRTSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate, table);
				return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate, table);
			}

		} else if("whitelist-data-report".equalsIgnoreCase(viewName)) {
			
			String statement = this.getSqlStatementHelper().getSqlStatement("getWhitelistDataExportReport");

			GridModelHandler gridModelHandler = new GridModelHandler(getDetailProperty(dataRequestModel));

			return baseReportsPrmDaoJdbcImpl.getReportsSimpleJdbcOperations().query(statement, gridModelHandler::handle, startDate, endDate);
			
		}
		return new GridModel();
	}

	@ExecutionTimeLogger
	public ResponseEntity<?> exportToPDF(ExportDataGridRequestModel requestModel) {

		byte[] pdfBytes = null;
		ResponseEntity<?> responseEntity = null;
		PdfPTable table = new PdfPTable(requestModel.getGridFieldsNames().size());
		Document document = new Document(PageSize.A4.rotate());
		PdfWriter writer = null;

		@SuppressWarnings("unchecked")
		List<List<FieldValue>> gridData = (List<List<FieldValue>>) filterGrid(requestModel);

		if (gridData.size() > genericDatalimit) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(genericErrorMessage);
		}

		String startDate = dateTimeUtils.unixToDateFormat(Long.parseLong(
				requestModel.getSearchRequestModel().getBetweenSearchGroups().get(0).getStartValue().toString()));
		String endDate = dateTimeUtils.unixToDateFormat(Long.parseLong(
				requestModel.getSearchRequestModel().getBetweenSearchGroups().get(0).getEndValue().toString()));

		try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {

			writer = PdfWriter.getInstance(document, byteArrayOutputStream);

			document.open();

			HeaderFooterPageEvent pageEvent = new HeaderFooterPageEvent();
			writer.setPageEvent(pageEvent);
			writer.setCompressionLevel(PdfStream.DEFAULT_COMPRESSION);

			List<Integer> indicesToInclude = new ArrayList<>();

			prepareHeadersPdf(document, startDate, endDate, requestModel);

			BaseColor headerBackgroundColor = new BaseColor(51, 69, 87);
			BaseColor dataBackground = new BaseColor(245, 247, 250);
			BaseColor borderColor = new BaseColor(82, 106, 126);

			Font headerFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
			Font dataFont = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);

			table.setWidthPercentage(100);
			table.setHeaderRows(1);
			table.setComplete(false);

			// Avoiding to split rows on page
			if (requestModel.getGridName().equals("full-action-report-summary")) {
				table.setSplitRows(true);
				table.setSplitLate(false);
			}

			setPdfColumnWidths(requestModel, table);

			for (String header : requestModel.getGridFieldsNames()) {

				if (getHeaderIndex(requestModel).containsKey(header)) {
					indicesToInclude.add(getHeaderIndex(requestModel).get(header));
				}
				PdfPCell cell = new PdfPCell(new Phrase(getDefaultHeaders(requestModel).get(header), headerFont));
				cell.setBackgroundColor(headerBackgroundColor);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				cell.setBorderColor(borderColor);
				table.addCell(cell);

			}

			int c = 0;
			for (List<FieldValue> rowData : gridData) {

				for (int i = 0; i <= getHeaderIndex(requestModel).size(); i++) {

					if (indicesToInclude.contains(i)) {
						FieldValue cellData = rowData.get(i);
						PdfPCell cell = new PdfPCell(new Phrase(cellData.toString(), dataFont));
						if (c % 2 == 0) {
							cell.setBorderColor(borderColor);
							cell.setBackgroundColor(dataBackground);
						}
						table.addCell(cell);
					}
				}
				c++;
				// Periodically flush rows for memory optimization
				if (c % pdfexportChunks == 0) {
					document.add(table); // Add the current table chunk to the document
					table.flushContent(); // Clear already rendered rows
				}
			}

			table.setComplete(true);
			document.add(table);

			document.close();

			pdfBytes = addPageNumbersToPdf(byteArrayOutputStream, document).toByteArray();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_PDF);
			headers.setContentDispositionFormData("filename", "export.pdf");
			headers.setContentLength(pdfBytes.length);

			responseEntity = new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);

			return responseEntity;
		} catch (Exception e) {
			logger.error("Exception occured while generating PDF : ", e);
			return new ResponseEntity<>(pdfBytes, HttpStatus.INTERNAL_SERVER_ERROR);
		} finally {

			try {
				pdfBytes = null;
				gridData = null;
				responseEntity = null;
				table = null;
				writer.close();
			} catch (Exception e) {
				logger.error("Exception occured while executing finally block in pdf generation : ", e);
			}
		}
	}

	@ExecutionTimeLogger
	private void prepareHeadersPdf(Document document, String startDate, String endDate,
			ExportDataGridRequestModel requestModel) throws DocumentException {

		// Set a smaller font size for the bullet points
		Font bulletFont = new Font(Font.FontFamily.HELVETICA, 10);
		// Create header in bold for first page
		Font boldFont = new Font(Font.FontFamily.HELVETICA, 13, Font.BOLD);
		Paragraph header = new Paragraph(getReportHeading(requestModel.getGridName()), boldFont);
		header.setAlignment(Element.ALIGN_LEFT);
		document.add(header);

		// Add small, controlled space after the header
		Paragraph spaceAfterHeader1 = new Paragraph();
		spaceAfterHeader1.setSpacingAfter(3f); // Adjust the space as needed
		document.add(spaceAfterHeader1);

		com.itextpdf.text.List bulletPoints = new com.itextpdf.text.List(com.itextpdf.text.List.UNORDERED);
		bulletPoints.add(new ListItem("Start Date : " + startDate, bulletFont));
		bulletPoints.add(new ListItem("End Date : " + endDate, bulletFont));
		
		if (!requestModel.getGridName().equals("full-action-report-summary")
				&& !"whitelist-data-report".equals(requestModel.getGridName())) {
			bulletPoints.add(new ListItem(
					"Channel Name : " + requestModel.getSearchRequestModel().getSimpleSearchGroup().get(0).getValue(),
					bulletFont));
		}
		
		bulletPoints.add(new ListItem("Report Type : " + getReportType(requestModel.getGridName()), bulletFont));

		document.add(bulletPoints);

		// Add small, controlled space after the header
		Paragraph spaceAfterbullets = new Paragraph();
		spaceAfterbullets.setSpacingAfter(10f);
		document.add(spaceAfterbullets);

	}

	@ExecutionTimeLogger
	public ByteArrayOutputStream addPageNumbersToPdf(ByteArrayOutputStream inputPdfStream, Document document)
			throws IOException, DocumentException {

		try (ByteArrayOutputStream outputPdfStream = new ByteArrayOutputStream()) {

			String formattedDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));

			PdfReader reader = new PdfReader(inputPdfStream.toByteArray());
			PdfStamper stamper = new PdfStamper(reader, outputPdfStream);

			int totalPages = reader.getNumberOfPages();

			for (int i = 1; i <= totalPages; i++) {
				PdfContentByte canvas = stamper.getOverContent(i);

				BaseFont baseFont = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI, false);
				canvas.beginText();
				canvas.setFontAndSize(baseFont, 10);

				String pageNumberText = "Page " + i + "/" + totalPages;

				canvas.showTextAligned(Element.ALIGN_RIGHT, pageNumberText, document.getPageSize().getRight() - 36,
						document.bottom() - 10, 0);

				canvas.showTextAligned(Element.ALIGN_LEFT, formattedDate, document.getPageSize().getLeft() + 36,
						document.bottom() - 10, 0);

				canvas.endText();
			}

			stamper.close();

			return outputPdfStream;
		}
	}

	@ExecutionTimeLogger
	public void setPdfColumnWidths(ExportDataGridRequestModel dataRequestModel, PdfPTable table)
			throws DocumentException {

		int[] selectedHeaders = new int[dataRequestModel.getGridFieldsNames().size()];
		float[] baseWidths = null;

		for (int i = 0; i < dataRequestModel.getGridFieldsNames().size(); i++) {
			String name = dataRequestModel.getGridFieldsNames().get(i);
			if (getHeaderIndex(dataRequestModel).containsKey(name)) {
				selectedHeaders[i] = getHeaderIndex(dataRequestModel).get(name);
			} else {
				selectedHeaders[i] = 0;
			}
		}

		if (dataRequestModel.getGridName().equals("sms-report-summary")) {
			baseWidths = new float[] { 0.8f, 1.5f, 1.5f, 1.3f, 0.8f };
		} else if (dataRequestModel.getGridName().equals("email-report-summary")) {
			baseWidths = new float[] { 0.8f, 1.5f, 1.5f, 1.3f, 0.8f };
		} else if (dataRequestModel.getGridName().equals("sms-report-detail")) {
			baseWidths = new float[] { 0.8f, 0.8f, 1.5f, 1.3f, 1f, 1.5f, 1.3f, 1.8f, 1.1f, 1.1f, 1.1f };
		} else if (dataRequestModel.getGridName().equals("email-report-detail")) {
			baseWidths = new float[] { 0.8f, 0.8f, 1.5f, 1.3f, 1f, 1.6f, 1.6f, 1.8f, 1.3f, 1.3f, 1.1f, 1.1f };
		} else if (dataRequestModel.getGridName().equals("full-action-report-summary")) {
			baseWidths = new float[] { 1.1f, 1.1f, 1.1f, 1.5f, 1.5f, 1f, 1f, 1.8f, 0.8f, 1f, 1.2f, 1f, 1f };
		} else if (dataRequestModel.getGridName().equals("mark-block-report-summary")) {
			baseWidths = new float[] { 1.3f, 1.5f, 1.5f, 1f, 1f, 1.5f, 1f, 1f, 1f, 1f };
		}else if("whitelist-data-report".equals(dataRequestModel.getGridName())) {
			baseWidths = new float[] { 1f, 0.8f, 1f, 1.3f, 0.5f, 1f, 1.5f };
		}

		float[] resultWidths = new float[selectedHeaders.length];

		for (int i = 0; i < selectedHeaders.length; i++) {
			int index = selectedHeaders[i];
			if (index < 0 || index >= baseWidths.length) {
				throw new IllegalArgumentException("Invalid header index: " + index);
			}
			resultWidths[i] = baseWidths[index];
		}
		table.setWidths(resultWidths);
	}

	@ExecutionTimeLogger
	private String getReportHeading(String gridName) {
		String result;
		switch (gridName) {
		case "sms-report-summary":
			result = "SMS Summary Report";
			break;
		case "email-report-summary":
			result = "Email Summary Report";
			break;
		case "sms-report-detail":
			result = "SMS Detail Report";
			break;
		case "email-report-detail":
			result = "Email Detail Report";
			break;
		case "full-action-report-summary":
			result = "Full Action Report";
			break;
		case "mark-block-report-summary":
			result = "Mark Block Report";
			break;
		default:
			result = "Report";
			break;
		}
		return result;
	}

	@ExecutionTimeLogger
	private String getReportType(String gridName) {
		String result;
		switch (gridName) {
		case "sms-report-summary":
			result = "Summary";
			break;
		case "email-report-summary":
			result = "Summary";
			break;
		case "sms-report-detail":
			result = "Detail";
			break;
		case "email-report-detail":
			result = "Detail";
			break;
		case "full-action-report-summary":
			result = "Full Action Report";
			break;
		case "mark-block-report-summary":
			result = "Mark Block Report";
			break;
		case "whitelist-data-report":
			result = "Whitelisted Data Report";
			break;
		default:
			result = "Report";
			break;
		}
		return result;
	}

	@ExecutionTimeLogger
	public ResponseEntity<?> exportToCsv(ExportDataGridRequestModel requestModel, String exportType)
			throws IOException {

		@SuppressWarnings("unchecked")
		List<List<FieldValue>> rowData = (List<List<FieldValue>>) filterGrid(requestModel);

		if (rowData.size() > genericDatalimit) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(genericErrorMessage);
		}

		List<String> header = requestModel.getGridFieldsNames();
		List<List<FieldValue>> listOfLists = rowData;

		List<LinkedHashMap<String, Object>> listOfMaps = convertForCSV(listOfLists, header,
				getReportType(requestModel.getGridName()), requestModel);

		// Convert header and data to CSV format
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

		// Write header
		writeLine(outputStream, null, requestModel.getGridFieldsNames(), "H", exportType, requestModel);
		outputStream.flush();

		// Write data rows
		for (LinkedHashMap<String, Object> row : listOfMaps) {
			writeLine(outputStream, row, null, "D", exportType, requestModel);
			outputStream.flush();
		}

		// Set response headers
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		return ResponseEntity.ok().headers(headers).body(outputStream.toByteArray());
	}

	@ExecutionTimeLogger
	private List<LinkedHashMap<String, Object>> convertForCSV(List<List<FieldValue>> listOfLists, List<String> header,
			String reportType, ExportDataGridRequestModel requestModel) {

		List<LinkedHashMap<String, Object>> listOfMaps = new ArrayList<>();

		if (listOfLists == null || listOfLists.isEmpty()) {
			return listOfMaps; // Return empty list if input is null or empty
		} else {

			List<String> headers = header;

			@SuppressWarnings("unused")
			List<FieldValue> rowData = listOfLists.get(0); // Assuming first row contains headers

			// Start from index 1 to skip header row
			for (int i = 0; i < listOfLists.size(); i++) {

				List<FieldValue> row = listOfLists.get(i);
				LinkedHashMap<String, Object> map = new LinkedHashMap<>();

				for (int j = 0; j < headers.size() && j < row.size(); j++) {

					map.put(getDefaultHeaders(requestModel).get(headers.get(j)),
							row.get(getHeaderIndex(requestModel).get(headers.get(j))));

				}
				listOfMaps.add(map);
			}
		}
		return listOfMaps;
	}

	@ExecutionTimeLogger
	private void writeLine(ByteArrayOutputStream outputStream, LinkedHashMap<String, Object> row, List<String> headers,
			String flag, String exportType, ExportDataGridRequestModel requestModel) throws IOException {

		char separator = ',';

		if (flag.equalsIgnoreCase("H")) {
			for (int i = 0; i < headers.size(); i++) {
				if (headers.get(i) != null) {
					if (exportType.equalsIgnoreCase("CSV")) {
						outputStream
								.write(("\"" + getDefaultHeaders(requestModel).get(headers.get(i).toString()) + "\"")
										.toString().getBytes(StandardCharsets.UTF_8));
					} else {
						outputStream.write(getDefaultHeaders(requestModel).get(headers.get(i).toString())
								.getBytes(StandardCharsets.UTF_8));

					}
				}
				if (i < headers.size() - 1) {
					outputStream.write(separator);
				}
			}
			outputStream.write('\n');
		} else if (flag.equalsIgnoreCase("D")) {

			List<Object> values = new ArrayList<>(row.values());

			for (int i = 0; i < row.size(); i++) {
				if (row.values() != null) {
					Object value = values.get(i);

					// if data contains the , then adding quotes to string
					if (exportType.equalsIgnoreCase("CSV")) {
						value = "\"" + value.toString().replace("\"", "\"\"") + "\"";
					}
					outputStream.write(value.toString().getBytes(StandardCharsets.UTF_8));
				}
				if (i < row.size() - 1) {
					outputStream.write(separator);
				}
			}
			outputStream.write('\n');
		}
	}

	@ExecutionTimeLogger
	public ResponseEntity<?> exportToXlsx(ExportDataGridRequestModel requestModel) throws IOException {

		@SuppressWarnings("unchecked")
		List<List<FieldValue>> gridData = (List<List<FieldValue>>) filterGrid(requestModel);

		if (gridData.size() > genericDatalimit) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(genericErrorMessage);
		}

		List<String> header = requestModel.getGridFieldsNames();
		List<List<FieldValue>> listOfLists = gridData;

		List<LinkedHashMap<String, Object>> listOfMaps = convertForCSV(listOfLists, header,
				getReportType(requestModel.getGridName()), requestModel);

		byte[] excelBytes = null;

		try (SXSSFWorkbook workbook = new SXSSFWorkbook(100);
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
			SXSSFSheet sheet = (SXSSFSheet) workbook.createSheet(requestModel.getGridName());
//		sheet.autoSizeColumn(0);
			@SuppressWarnings("unused")
			MutableInt headerColumnIdx = new MutableInt(0);

			int rowNum0 = 0;
			for (@SuppressWarnings("unused")
			String headerData : header) {
				SXSSFRow sXSSFRow = (SXSSFRow) sheet.createRow(rowNum0);
				int colNum = 0;
				for (int i = 0; i < header.size(); i++) {
					Cell cell = sXSSFRow.createCell(colNum++);
					cell.setCellValue(getDefaultHeaders(requestModel).get(header.get(i).toString()));
				}
			}

			// Write data to the sheet
			int rowNum = 1;
			for (LinkedHashMap<String, Object> rowData : listOfMaps) {
				Row row = sheet.createRow(rowNum++);
				int colNum = 0;

				List<Object> values = new ArrayList<>(rowData.values());

				for (int i = 0; i < rowData.size(); i++) {
					if (rowData.values() != null) {
						Object value = values.get(i);
						Cell cell = row.createCell(colNum++);
						cell.setCellValue(value.toString());
					}
				}
			}

			// Set response headers
			HttpHeaders headers = new HttpHeaders();
			headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=data.xlsx");
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

			sheet.trackAllColumnsForAutoSizing();
			IntStream.range(0, requestModel.getGridFieldsNames().size()).forEach(sheet::autoSizeColumn);

			// Write workbook to the response stream
			workbook.write(outputStream);
			workbook.close();

			excelBytes = outputStream.toByteArray();

			// Close workbook
			workbook.dispose();

			return new ResponseEntity<>(excelBytes, headers, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception occured while writing data in excel", e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		} finally {
			excelBytes = null;
		}
	}
}
