package com.concerto.prm.csm.report.dao;

import org.springframework.stereotype.Service;

import com.concerto.prm.aop.ExecutionTimeLogger;

@Service
public class CommonSqlQueryDao {

	// MASKED SMS DETAIL Report switch view name
	@ExecutionTimeLogger
	protected String getSMSMaskedDetailReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getMaskedCardDetailReport";
				break;
			case "PREPAID CARD":
				result = "getMaskedPrepaidCardDetailReport";
				break;
			case "RINB":
				result = "getMaskedRinbDetailReport";
				break;
			case "UPI":
				result = "getMaskedUpiDetailReport";
				break;
			case "YONO":
				result = "getMaskedYonoDetailReport";
				break;
			case "YONO LITE":
				result = "getMaskedYonoLiteDetailReport";
				break;
			case "FASTag":
				result = "getMaskedFastTagDetailReport";
				break;
			case "CINB":
				result = "getMaskedCinbDetailReport";
				break;
			case "KIOSK":
				result = "getMaskedKioskDetailReport";
				break;
			case "CBDC":
				result = "getMaskedCbdcDetailReport";
				break;
			case "YONO 2.0":
				result = "getMaskedYn20DetailReport";
				break;
			case "CMPI":
				result = "getMaskedCMPIDetailReport";
				break;
			// New channels added
			case "UPFI":
				result = "getMaskedUPFIDetailReport";
				break;
			case "IMPC":
				result = "getMaskedIMPCDetailReport";
				break;
			case "NEFC":
				result = "getMaskedNEFCDetailReport";
				break;
			case "RTGC":
				result = "getMaskedRTGCDetailReport";
				break;
			default:
				result = "getDefaultDetailReport";
				break;
		}
		return result;
	}

	// MASKED SMS DETAIL Report switch view name
	@ExecutionTimeLogger
	protected String getSMSArMaskedDetailReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArMaskedCardDetailReport";
				break;
			case "PREPAID CARD":
				result = "getArMaskedPrepaidCardDetailReport";
				break;
			case "RINB":
				result = "getArMaskedRinbDetailReport";
				break;
			case "UPI":
				result = "getArMaskedUpiDetailReport";
				break;
			case "YONO":
				result = "getArMaskedYonoDetailReport";
				break;
			case "YONO LITE":
				result = "getArMaskedYonoLiteDetailReport";
				break;
			case "FASTag":
				result = "getArMaskedFastTagDetailReport";
				break;
			case "CINB":
				result = "getArMaskedCinbDetailReport";
				break;
			case "KIOSK":
				result = "getArMaskedKioskDetailReport";
				break;
			case "CBDC":
				result = "getArMaskedCbdcDetailReport";
				break;
			case "YONO 2.0":
				result = "getArMaskedYn20DetailReport";
				break;
			case "CMPI":
				result = "getArMaskedCMPIDetailReport";
				break;
			// New channels added
			case "UPFI":
				result = "getArMaskedUPFIDetailReport";
				break;
			case "IMPC":
				result = "getArMaskedIMPCDetailReport";
				break;
			case "NEFC":
				result = "getArMaskedNEFCDetailReport";
				break;
			case "RTGC":
				result = "getArMaskedRTGCDetailReport";
				break;
			default:
				result = "getArDefaultDetailReport";
				break;
		}
		return result;
	}

	// detail Report switch view name to find total count switch
	@ExecutionTimeLogger
	protected String getSMSDetailReportCount(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getCardDetailReportCount";
				break;
			case "PREPAID CARD":
				result = "getPrepaidCardDetailReportCount";
				break;
			case "RINB":
				result = "getRinbDetailReportCount";
				break;
			case "UPI":
				result = "getUpiDetailReportCount";
				break;
			case "YONO":
				result = "getYonoDetailReportCount";
				break;
			case "YONO LITE":
				result = "getYonoLiteDetailReportCount";
				break;
			case "FASTag":
				result = "getFastTagDetailReportCount";
				break;
			case "CINB":
				result = "getCinbDetailReportCount";
				break;
			case "KIOSK":
				result = "getKioskDetailReportCount";
				break;
			case "CBDC":
				result = "getCbdcDetailReportCount";
				break;
			case "YONO 2.0":
				result = "getYn20DetailReportCount";
				break;
			case "CMPI":
				result = "getCMPIDetailReportCount";
				break;
			// New channels added
			case "UPFI":
				result = "getUPFIDetailReportCount";
				break;
			case "IMPC":
				result = "getIMPCDetailReportCount";
				break;
			case "NEFC":
				result = "getNEFCDetailReportCount";
				break;
			case "RTGC":
				result = "getRTGCDetailReportCount";
				break;
			default:
				result = "getDefaultDetailReportCount";
				break;
		}
		return result;
	}

	// detail Report switch view name to find total count switch
	@ExecutionTimeLogger
	protected String getSMSArDetailReportCount(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArCardDetailReportCount";
				break;
			case "PREPAID CARD":
				result = "getArPrepaidCardDetailReportCount";
				break;
			case "RINB":
				result = "getArRinbDetailReportCount";
				break;
			case "UPI":
				result = "getArUpiDetailReportCount";
				break;
			case "YONO":
				result = "getArYonoDetailReportCount";
				break;
			case "YONO LITE":
				result = "getArYonoLiteDetailReportCount";
				break;
			case "FASTag":
				result = "getArFastTagDetailReportCount";
				break;
			case "CINB":
				result = "getArCinbDetailReportCount";
				break;
			case "KIOSK":
				result = "getArKioskDetailReportCount";
				break;
			case "CBDC":
				result = "getArCbdcDetailReportCount";
				break;
			case "YONO 2.0":
				result = "getArYn20DetailReportCount";
				break;
			case "CMPI":
				result = "getArCMPIDetailReportCount";
				break;
			// New channels added
			case "UPFI":
				result = "getArUPFIDetailReportCount";
				break;
			case "IMPC":
				result = "getArIMPCDetailReportCount";
				break;
			case "NEFC":
				result = "getArNEFCDetailReportCount";
				break;
			case "RTGC":
				result = "getArRTGCDetailReportCount";
				break;
			default:
				result = "getArDefaultDetailReportCount";
				break;
		}
		return result;
	}

	// SMS Summary Report switch view name
	@ExecutionTimeLogger
	protected String getSMSMaskedSummaryReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getMaskedCardSummaryReport";
				break;
			case "PREPAID CARD":
				result = "getMaskedPrepaidCardSummaryReport";
				break;
			case "RINB":
				result = "getMaskedRinbSummaryReport";
				break;
			case "UPI":
				result = "getMaskedUpiSummaryReport";
				break;
			case "YONO":
				result = "getMaskedYonoSummaryReport";
				break;
			case "YONO LITE":
				result = "getMaskedYonoLiteSummaryReport";
				break;
			case "FASTag":
				result = "getMaskedFastTagSummaryReport";
				break;
			case "CINB":
				result = "getMaskedCinbSummaryReport";
				break;
			case "KIOSK":
				result = "getMaskedKioskSummaryReport";
				break;
			case "CBDC":
				result = "getMaskedCbdcSummaryReport";
				break;
			case "YONO 2.0":
				result = "getMaskedYn20SummaryReport";
				break;
			case "CMPI":
				result = "getMaskedCMPISummaryReport";
				break;
			// New channels added
			case "UPFI":
				result = "getMaskedUPFISummaryReport";
				break;
			case "IMPC":
				result = "getMaskedIMPCSummaryReport";
				break;
			case "NEFC":
				result = "getMaskedNEFCSummaryReport";
				break;
			case "RTGC":
				result = "getMaskedRTGCSummaryReport";
				break;
			default:
				result = "getDefaultSummaryReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getSMSSummaryReportCount(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getCardSummaryReportCount";
				break;
			case "PREPAID CARD":
				result = "getPrepaidCardSummaryReportCount";
				break;
			case "RINB":
				result = "getRinbSummaryReportCount";
				break;
			case "UPI":
				result = "getUpiSummaryReportCount";
				break;
			case "YONO":
				result = "getYonoSummaryReportCount";
				break;
			case "YONO LITE":
				result = "getYonoLiteSummaryReportCount";
				break;
			case "FASTag":
				result = "getFastTagSummaryReportCount";
				break;
			case "CINB":
				result = "getCinbSummaryReportCount";
				break;
			case "KIOSK":
				result = "getKioskSummaryReportCount";
				break;
			case "CBDC":
				result = "getCbdcSummaryReportCount";
				break;
			case "YONO 2.0":
				result = "getYn20SummaryReportCount";
				break;
			case "CMPI":
				result = "getCMPISummaryReportCount";
				break;
			// New channels added
			case "UPFI":
				result = "getUPFISummaryReportCount";
				break;
			case "IMPC":
				result = "getIMPCSummaryReportCount";
				break;
			case "NEFC":
				result = "getNEFCSummaryReportCount";
				break;
			case "RTGC":
				result = "getRTGCSummaryReportCount";
				break;
			default:
				result = "getDefaultSummaryReportCount";
				break;
		}
		return result;
	}

	// SMS Summary Report switch view name
	@ExecutionTimeLogger
	protected String getSMSMaskedArSummaryReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArMaskedCardSummaryReport";
				break;
			case "PREPAID CARD":
				result = "getArMaskedPrepaidCardSummaryReport";
				break;
			case "RINB":
				result = "getArMaskedRinbSummaryReport";
				break;
			case "UPI":
				result = "getArMaskedUpiSummaryReport";
				break;
			case "YONO":
				result = "getArMaskedYonoSummaryReport";
				break;
			case "YONO LITE":
				result = "getArMaskedYonoLiteSummaryReport";
				break;
			case "FASTag":
				result = "getArMaskedFastTagSummaryReport";
				break;
			case "CINB":
				result = "getArMaskedCinbSummaryReport";
				break;
			case "KIOSK":
				result = "getArMaskedKioskSummaryReport";
				break;
			case "CBDC":
				result = "getArMaskedCbdcSummaryReport";
				break;
			case "YONO 2.0":
				result = "getArMaskedYn20SummaryReport";
				break;
			case "CMPI":
				result = "getArMaskedCMPISummaryReport";
				break;
			// New channels added
			case "UPFI":
				result = "getArMaskedUPFISummaryReport";
				break;
			case "IMPC":
				result = "getArMaskedIMPCSummaryReport";
				break;
			case "NEFC":
				result = "getArMaskedNEFCSummaryReport";
				break;
			case "RTGC":
				result = "getArMaskedRTGCSummaryReport";
				break;
			default:
				result = "getArDefaultSummaryReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getSMSArSummaryReportCount(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArCardSummaryReportCount";
				break;
			case "PREPAID CARD":
				result = "getArPrepaidCardSummaryReportCount";
				break;
			case "RINB":
				result = "getArRinbSummaryReportCount";
				break;
			case "UPI":
				result = "getArUpiSummaryReportCount";
				break;
			case "YONO":
				result = "getArYonoSummaryReportCount";
				break;
			case "YONO LITE":
				result = "getArYonoLiteSummaryReportCount";
				break;
			case "FASTag":
				result = "getArFastTagSummaryReportCount";
				break;
			case "CINB":
				result = "getArCinbSummaryReportCount";
				break;
			case "KIOSK":
				result = "getArKioskSummaryReportCount";
				break;
			case "CBDC":
				result = "getArCbdcSummaryReportCount";
				break;
			case "YONO 2.0":
				result = "getArYn20SummaryReportCount";
				break;
			case "CMPI":
				result = "getArCMPISummaryReportCount";
				break;
			// New channels added
			case "UPFI":
				result = "getArUPFISummaryReportCount";
				break;
			case "IMPC":
				result = "getArIMPCSummaryReportCount";
				break;
			case "NEFC":
				result = "getArNEFCSummaryReportCount";
				break;
			case "RTGC":
				result = "getArRTGCSummaryReportCount";
				break;
			default:
				result = "getArDefaultSummaryReportCount";
				break;
		}
		return result;
	}

	// EMAIL Summary Report switch view name
	@ExecutionTimeLogger
	protected String getEmailSummaryReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getEmailCardSummaryReport";
				break;
			case "PREPAID CARD":
				result = "getEmailPrepaidCardSummaryReport";
				break;
			case "RINB":
				result = "getEmailRinbSummaryReport";
				break;
			case "UPI":
				result = "getEmailUpiSummaryReport";
				break;
			case "YONO":
				result = "getEmailYonoSummaryReport";
				break;
			case "YONO LITE":
				result = "getEmailYonoLiteSummaryReport";
				break;
			case "FASTag":
				result = "getEmailFastTagSummaryReport";
				break;
			case "CINB":
				result = "getEmailCinbSummaryReport";
				break;
			case "KIOSK":
				result = "getEmailKioskSummaryReport";
				break;
			case "CBDC":
				result = "getEmailCbdcSummaryReport";
				break;
			case "YONO 2.0":
				result = "getEmailYn20SummaryReport";
				break;
			case "CMPI":
				result = "getEmailCMPISummaryReport";
				break;
			default:
				result = "getEmailDefaultSummaryReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getEmailSummaryReportCount(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getEmailCardSummaryReportCount";
				break;
			case "PREPAID CARD":
				result = "getEmailPrepaidCardSummaryReportCount";
				break;
			case "RINB":
				result = "getEmailRinbSummaryReportCount";
				break;
			case "UPI":
				result = "getEmailUpiSummaryReportCount";
				break;
			case "YONO":
				result = "getEmailYonoSummaryReportCount";
				break;
			case "YONO LITE":
				result = "getEmailYonoLiteSummaryReportCount";
				break;
			case "FASTag":
				result = "getEmailFastTagSummaryReportCount";
				break;
			case "CINB":
				result = "getEmailCinbSummaryReportCount";
				break;
			case "KIOSK":
				result = "getEmailKioskSummaryReportCount";
				break;
			case "CBDC":
				result = "getEmailCbdcSummaryReportCount";
				break;
			case "YONO 2.0":
				result = "getEmailYn20SummaryReportCount";
				break;
			case "CMPI":
				result = "getEmailCMPISummaryReportCount";
				break;
			default:
				result = "getEmailDefaultDetailReportCount";
				break;
		}
		return result;
	}

	// EMAIL AR Summary Report switch view name
	@ExecutionTimeLogger
	protected String getEmailArSummaryReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArEmailCardSummaryReport";
				break;
			case "PREPAID CARD":
				result = "getArEmailPrepaidCardSummaryReport";
				break;
			case "RINB":
				result = "getArEmailRinbSummaryReport";
				break;
			case "UPI":
				result = "getArEmailUpiSummaryReport";
				break;
			case "YONO":
				result = "getArEmailYonoSummaryReport";
				break;
			case "YONO LITE":
				result = "getArEmailYonoLiteSummaryReport";
				break;
			case "FASTag":
				result = "getArEmailFastTagSummaryReport";
				break;
			case "CINB":
				result = "getArEmailCinbSummaryReport";
				break;
			case "KIOSK":
				result = "getArEmailKioskSummaryReport";
				break;
			case "CBDC":
				result = "getArEmailCbdcSummaryReport";
				break;
			case "YONO 2.0":
				result = "getArEmailYn20SummaryReport";
				break;
			case "CMPI":
				result = "getArEmailCMPISummaryReport";
				break;
			default:
				result = "getArEmailDefaultSummaryReport";
				break;
		}
		return result;
	}

	@ExecutionTimeLogger
	protected String getEmailArSummaryReportCount(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArEmailCardSummaryReportCount";
				break;
			case "PREPAID CARD":
				result = "getArEmailPrepaidCardSummaryReportCount";
				break;
			case "RINB":
				result = "getArEmailRinbSummaryReportCount";
				break;
			case "UPI":
				result = "getArEmailUpiSummaryReportCount";
				break;
			case "YONO":
				result = "getArEmailYonoSummaryReportCount";
				break;
			case "YONO LITE":
				result = "getArEmailYonoLiteSummaryReportCount";
				break;
			case "FASTag":
				result = "getArEmailFastTagSummaryReportCount";
				break;
			case "CINB":
				result = "getArEmailCinbSummaryReportCount";
				break;
			case "KIOSK":
				result = "getArEmailKioskSummaryReportCount";
				break;
			case "CBDC":
				result = "getArEmailCbdcSummaryReportCount";
				break;
			case "YONO 2.0":
				result = "getArEmailYn20SummaryReportCount";
				break;
			case "CMPI":
				result = "getArEmailCMPISummaryReportCount";
				break;
			default:
				result = "getEmailDefaultDetailReportCount";
				break;
		}
		return result;
	}

	// EMAIL DETAIL Report switch view name
	protected String getEmailMaskedDetailReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getMaskedEmailCardDetailReport";
				break;
			case "PREPAID CARD":
				result = "getMaskedEmailPrepaidCardDetailReport";
				break;
			case "RINB":
				result = "getMaskedEmailRinbDetailReport";
				break;
			case "UPI":
				result = "getMaskedEmailUpiDetailReport";
				break;
			case "YONO":
				result = "getMaskedEmailYonoDetailReport";
				break;
			case "YONO LITE":
				result = "getMaskedEmailYonoLiteDetailReport";
				break;
			case "FASTag":
				result = "getMaskedEmailFastTagDetailReport";
				break;
			case "CINB":
				result = "getMaskedEmailCinbDetailReport";
				break;
			case "KIOSK":
				result = "getMaskedEmailKioskDetailReport";
				break;
			case "CBDC":
				result = "getMaskedEmailCbdcDetailReport";
				break;
			case "YONO 2.0":
				result = "getMaskedEmailYn20DetailReport";
				break;
			case "CMPI":
				result = "getMaskedEmailCMPIDetailReport";
				break;
			default:
				result = "getEmailDefaultDetailReport";
				break;
		}
		return result;
	}

	// detail Report switch view name to find total count switch
	protected String getEmailDetailReportCount(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getEmailCardDetailReportCount";
				break;
			case "PREPAID CARD":
				result = "getEmailPrepaidCardDetailReportCount";
				break;
			case "RINB":
				result = "getEmailRinbDetailReportCount";
				break;
			case "UPI":
				result = "getEmailUpiDetailReportCount";
				break;
			case "YONO":
				result = "getEmailYonoDetailReportCount";
				break;
			case "YONO LITE":
				result = "getEmailYonoLiteDetailReportCount";
				break;
			case "FASTag":
				result = "getEmailFastTagDetailReportCount";
				break;
			case "CINB":
				result = "getEmailCinbDetailReportCount";
				break;
			case "KIOSK":
				result = "getEmailKioskDetailReportCount";
				break;
			case "CBDC":
				result = "getEmailCbdcDetailReportCount";
				break;
			case "YONO 2.0":
				result = "getEmailYn20DetailReportCount";
				break;
			case "CMPI":
				result = "getEmailCMPIDetailReportCount";
				break;
			default:
				result = "getEmailDefaultDetailReportCount";
				break;
		}
		return result;
	}

	// EMAIL DETAIL Report switch view name
	protected String getEmailArMaskedDetailReport(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArMaskedEmailCardDetailReport";
				break;
			case "PREPAID CARD":
				result = "getArMaskedEmailPrepaidCardDetailReport";
				break;
			case "RINB":
				result = "getArMaskedEmailRinbDetailReport";
				break;
			case "UPI":
				result = "getArMaskedEmailUpiDetailReport";
				break;
			case "YONO":
				result = "getArMaskedEmailYonoDetailReport";
				break;
			case "YONO LITE":
				result = "getArMaskedEmailYonoLiteDetailReport";
				break;
			case "FASTag":
				result = "getArMaskedEmailFastTagDetailReport";
				break;
			case "CINB":
				result = "getArMaskedEmailCinbDetailReport";
				break;
			case "KIOSK":
				result = "getArMaskedEmailKioskDetailReport";
				break;
			case "CBDC":
				result = "getArMaskedEmailCbdcDetailReport";
				break;
			case "YONO 2.0":
				result = "getArMaskedEmailYn20DetailReport";
				break;
			case "CMPI":
				result = "getArMaskedEmailCMPIDetailReport";
				break;
			default:
				result = "getArEmailDefaultDetailReport";
				break;
		}
		return result;
	}

	// detail Report switch view name to find total count switch
	protected String getEmailArDetailReportCount(String channelName) {
		String result;
		switch (channelName) {
			case "CARD":
				result = "getArEmailCardDetailReportCount";
				break;
			case "PREPAID CARD":
				result = "getArEmailPrepaidCardDetailReportCount";
				break;
			case "RINB":
				result = "getArEmailRinbDetailReportCount";
				break;
			case "UPI":
				result = "getArEmailUpiDetailReportCount";
				break;
			case "YONO":
				result = "getArEmailYonoDetailReportCount";
				break;
			case "YONO LITE":
				result = "getArEmailYonoLiteDetailReportCount";
				break;
			case "FASTag":
				result = "getArEmailFastTagDetailReportCount";
				break;
			case "CINB":
				result = "getArEmailCinbDetailReportCount";
				break;
			case "KIOSK":
				result = "getArEmailKioskDetailReportCount";
				break;
			case "CBDC":
				result = "getArEmailCbdcDetailReportCount";
				break;
			case "YONO 2.0":
				result = "getArEmailYn20DetailReportCount";
				break;
			case "CMPI":
				result = "getArEmailCMPIDetailReportCount";
				break;
			default:
				result = "getArEmailDefaultDetailReportCount";
				break;
		}
		return result;
	}

}
