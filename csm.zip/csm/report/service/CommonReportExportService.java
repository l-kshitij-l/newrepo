package com.concerto.prm.csm.report.service;

import java.io.IOException;

import javax.xml.transform.TransformerException;

import org.apache.fop.apps.FOPException;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.aciworldwide.rms.ar.grid.common.model.ExportDataGridRequestModel;
import com.concerto.prm.csm.report.dao.CommonReportExportDao;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CommonReportExportService {

	private CommonReportExportDao dataExportDao;

	public ResponseEntity<?> exportToPDF(@RequestBody ExportDataGridRequestModel requestModel)
			throws FOPException, TransformerException, IOException {
		return dataExportDao.exportToPDF(requestModel);
	}

	public ResponseEntity<?> exportToCsv(@RequestBody ExportDataGridRequestModel requestModel, String exportType)
			throws FOPException, TransformerException, IOException {
		return dataExportDao.exportToCsv(requestModel, exportType);
	}

	public ResponseEntity<?> exportToXlsx(@RequestBody ExportDataGridRequestModel requestModel)
			throws FOPException, TransformerException, IOException {
		return dataExportDao.exportToXlsx(requestModel);
	}
}
