package com.concerto.prm.csm.report.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.aciworldwide.rms.ar.grid.common.model.DataGridRequestModel;
import com.aciworldwide.rms.ar.grid.common.model.GridModel;
import com.concerto.prm.csm.report.dao.CommonReportDao;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CommonReportService {

	private CommonReportDao commonReportDao;

	public GridModel getAsGroupGrid(DataGridRequestModel dataRequestModel, String viewName) {

		if (dataRequestModel.getSearchRequestModel() == null) {
			return commonReportDao.getDefaultSummaryGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() == null
				|| dataRequestModel.getSearchRequestModel().getSimpleSearchGroup() == null
						&& viewName.equalsIgnoreCase("sms-report-summary")) {
			return commonReportDao.getDefaultSummaryGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel() != null
				&& viewName.equalsIgnoreCase("sms-report-summary")) {
			return commonReportDao.getReportSummaryGroupGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() == null
				|| dataRequestModel.getSearchRequestModel().getSimpleSearchGroup() == null
						&& viewName.equalsIgnoreCase("email-report-summary")) {
			return commonReportDao.getDefaultSummaryGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel() != null
				&& viewName.equalsIgnoreCase("email-report-summary")) {
			return commonReportDao.getReportSummaryGroupGrid(dataRequestModel, viewName);
		} else {
			return commonReportDao.getDefaultSummaryGrid(dataRequestModel, viewName);
		}

	}

	public GridModel getAsGrid(DataGridRequestModel dataRequestModel, String viewName) {

		if (dataRequestModel.getSearchRequestModel() == null) {
			return commonReportDao.getDefaultDetailGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() == null
				&& viewName.equalsIgnoreCase("sms-report-detail")) {
			return commonReportDao.getDefaultDetailGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() == null
				&& viewName.equalsIgnoreCase("email-report-detail")) {
			return commonReportDao.getDefaultDetailGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() == null
				&& viewName.equalsIgnoreCase("full-action-report-summary")) {
			return commonReportDao.getDefaultDetailGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() == null
				&& viewName.equalsIgnoreCase("mark-block-report-summary")) {
			return commonReportDao.getDefaultDetailGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() != null
				&& viewName.equalsIgnoreCase("email-report-detail")) {
			return commonReportDao.getReportDetailGroupGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() != null
				&& viewName.equalsIgnoreCase("sms-report-detail")) {
			return commonReportDao.getReportDetailGroupGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() != null
				&& viewName.equalsIgnoreCase("full-action-report-summary")) {
			return commonReportDao.getReportDetailGroupGrid(dataRequestModel, viewName);
		} else if (dataRequestModel.getSearchRequestModel().getBetweenSearchGroups() != null
				&& viewName.equalsIgnoreCase("mark-block-report-summary")) {
			return commonReportDao.getReportDetailGroupGrid(dataRequestModel, viewName);
		} else {
			return commonReportDao.getDefaultDetailGrid(dataRequestModel, viewName);
		}

	}

	public List<String> getChannelName(String viewName) {
		if (viewName.equalsIgnoreCase("sms-report-summary")) {
			viewName = "SMS";
			return commonReportDao.getChannelName(viewName);
		} else if (viewName.equalsIgnoreCase("email-report-summary")) {
			viewName = "EMAIL";
			return commonReportDao.getChannelName(viewName);
		} else if (viewName.equalsIgnoreCase("mark-block-report-summary")) {
			return commonReportDao.getChannelName(viewName);
		} else {
			return commonReportDao.getChannelName(viewName);
		}
	}

}