import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ManualEmailModule } from './manual-email/manual-email.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    ManualEmailModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
