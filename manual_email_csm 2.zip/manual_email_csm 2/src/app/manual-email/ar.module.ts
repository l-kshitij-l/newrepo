import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PermissionsModule } from '@ar/auth-lib';
import { ArIconsModule, DynamicViewCommonModule, ViewFragmentModule, ArTooltipModule, ArTranslateModule, ArInputModule, ArSelectModule, ArSwitchToggleModule, ArBreadcrumbsModule } from '@ar/components-lib';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ArIconsModule,
    DynamicViewCommonModule,
    ViewFragmentModule,
    ArTooltipModule,
    ArTranslateModule,
    ArInputModule,
    ArSelectModule,
    ArSwitchToggleModule,
    ArBreadcrumbsModule,
    PermissionsModule,
  ],
  exports: [
    ArIconsModule,
    DynamicViewCommonModule,
    ViewFragmentModule,
    ArTooltipModule,
    ArTranslateModule,
    ArInputModule,
    ArSelectModule,
    ArSwitchToggleModule,
    ArBreadcrumbsModule,
    PermissionsModule,
  ]
})
export class ArModule { 
  
}
