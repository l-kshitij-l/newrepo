import {Directive, Input} from "@angular/core";
import {AbstractEventModel, AbstractViewElement, ViewFragment, ViewFragmentEventModel} from '@ar/components-lib';
import {Subject} from "rxjs";

/**
 * Base class for dynamic components (components rendered by viewFragment)
 * This call needs to annotated with @Directive for the angular compiler
 */
@Directive({selector: 'lib-base-dynamic-component'})
export class BaseDynamicComponent {

  /**
   * Subject stream that allows communication between all the components of a view fragment
   * Will be initialized by the up-ext-view-fragment component and passed down to all of it's children
   **/
  @Input() viewFragmentEvent: Subject<ViewFragmentEventModel<any, any>>;

  /**
   * the current viewElement object
   */
  @Input() viewElement: any;

  /**
   * The parrent viewElement object. will be undefiend for root elements
   */
  @Input() parentElement: AbstractViewElement | undefined;

  /**
   * the ViewFragment object
   */
  @Input() viewFragment: ViewFragment | undefined;

  /**
   * Additional data object. It is shared between all viewElements of a viewFragment
   */
  @Input() viewFragmentData: any;


  emitEvent(event: AbstractEventModel) {
    this.viewFragmentEvent.next(new ViewFragmentEventModel<any, any>(this.viewElement, event));
 }

}
