import { Component, OnDestroy, OnInit, ViewEncapsulation } from "@angular/core";
import {
  AbstractControl,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import {
  AlertLevel,
  ArActiveModalRef,
  GlobalNotificationService,
  KeyHandlerService,
  UntranslatedBootstrapAlert,
} from "@ar/components-lib";
import { Editor, NgxEditorService, Toolbar } from "ngx-editor";
import { ManualEmailService } from "../manual-email.service";
import { DimensionIdStreamService } from "@ar/main-app";
import { checkFlag } from "../model/is-Enable";
import { PopulateEmailModel } from "../model/populateEmailModel";
import { formatDate } from "@angular/common";
import { sendEmailFieldModel } from "../model/sendEmail";
import { ArPermissionType, AuthenticationService } from "@ar/auth-lib";

import { HostAndChannelName } from "../model/channel-name-and-host";
import { PortfolioIdParamsModel } from "../model/PortfolioIdParams";

@Component({
  selector: "app-email-template-review-dialog",
  templateUrl: "./email-template-review-dialog.component.html",
  styleUrls: ["./email-template-review-dialog.component.scss"],
  encapsulation: ViewEncapsulation.Emulated,
})
export class EmailTemplateReviewDialogComponent implements OnInit, OnDestroy {
  headerTextTranslationKey: string = "lib-email-template-review-dialog.title";

  formGroup: any;
  isDesabled: any;
  sendBtnTranslationKey: string =
    "lib-email-template-review-dialog.send.button";
  closeBtnTranslationKey: string =
    "lib-email-template-review-dialog.close.button";
  refreshBtnTranslationKey: string =
    "lib-email-template-review-dialog.refresh.button";

  allTemplates: any;
  addCCButtonText: string = "view.email.dialog.button.add.CC";
  addBCCButtonText: string = "view.email.dialog.button.add.BCC";
  editor: Editor;
  cursPos: number;
  AddCC: boolean = false;
  enableFlag: checkFlag = new checkFlag();
  toolbar: Toolbar = [
    ["bold", "italic"],
    ["underline", "strike"],
    ["ordered_list", "bullet_list"],
    ["text_color", "background_color"],
    [{ heading: ["h1", "h2", "h3", "h4", "h5", "h6"] }],
    ["align_left", "align_center", "align_right", "align_justify"],
  ];
  AddBCC: boolean = false;
  currentTransaction: any;
  msgType: any[];
  channel_id: any;
  tooltip: string;
  emailTemplates: any;
  uiFields: any;
  sdMessType: any[];
  sdMessageType: any;
  sdPortfolio: any[];
  sdPrtfolioId: any;
  sendSMSFieldModel: sendEmailFieldModel;
  templateID: any;
  actionLvlKey: any;
  tieBreaker: any;
  txnDate: any;
  partDate: any;
  ndHashKey: any;
  recordSrcId: any;
  portfolioId: any;
  modalAlert: UntranslatedBootstrapAlert;
  message: any;
  emailToError: boolean = false;
  controls: any;
  showRefresh: boolean = false;
  emailregex: RegExp =
    /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  private _sendEmail: sendEmailFieldModel;
  userAcctId: any;
  userAcctIdKey: any;
  channel_name: any;
  messageId: any;

  portfolioIds: any;
  channelName: any;
  sdHostDecision: any;
  sdHost: any;
  isRefreshBtnDesabled: boolean = false;
  SD_PRI_ACCT_NUM: any;
  actionLvlId: any;
  sdPan: any;
  portfolioIdForAccout: any;

  dimensionsMap = [
    { id: "6", values: "6-true" },
    { id: "7", values: "7-true" },
    { id: "1", values: "1-true" },
  ];
  actionLvlIdTempList: any;
  actionLvlIdTemp: any;

  constructor(
    private _activeModal: ArActiveModalRef,
    private dimensionIdStreamService: DimensionIdStreamService,
    private emailService: ManualEmailService,
    private globalNotificationService: GlobalNotificationService,
    private authService: AuthenticationService,
    private keyHandlerService: KeyHandlerService
  ) { }

  ngOnInit(): void {
    this.editor = new Editor();

    this.formGroup = new FormGroup({
      templateName: new FormControl("", Validators.required),
      subject: new FormControl("", Validators.required),
      mail_from: new FormControl("", Validators.required),
      mail_to: new FormControl("", [Validators.required, this.commaSepEmail]),
      mail_cc: new FormControl("", this.commaSepEmail),
      templateText: new FormControl("", Validators.required),
    });

    this.controls = {
      templateName: this.formGroup.get("templateName"),
      subject: this.formGroup.get("subject"),
      mail_from: this.formGroup.get("mail_from"),
      mail_to: this.formGroup.get("mail_to"),
      mail_cc: this.formGroup.get("mail_cc"),
      templateText: this.formGroup.get("templateText"),
    };

    this.formGroup.get("mail_from")?.disable();

    this.currentTransaction =
      this.dimensionIdStreamService.activeDimensionDetails.selectedTransactions;
    this.sdMessType = Array.from(this.currentTransaction.values()).map(
      (item: any) => Object.assign({ messsageType: item["SD_MSG_TYP"].value })
    );

    this.sdMessageType = this.sdMessType[0].messsageType;

    let userAcctId = Array.from(this.currentTransaction.values()).map(
      (item: any) =>
        Object.assign({ userAcctId: item["SD_USER_ACCT_ID"].value })
    );

    this.userAcctId = userAcctId[0].userAcctId;

    // this.userAcctIdKey = this.userAcctId.split(/\s*\-\s*/g)[0].slice(0, 6);

    let RECORD_SRC_ID: any = Array.from(this.currentTransaction.values()).map(
      (item: any) =>
        Object.assign({ recorSrcId: item["RECORD_SOURCE_ID"].value })
    );
    let ND_HASH_KEY: any = Array.from(this.currentTransaction.values()).map(
      (item: any) => Object.assign({ hashKey: item["ND_KEY_HASH"].value })
    );
    let DD_PART_DATE: any = Array.from(this.currentTransaction.values()).map(
      (item: any) =>
        Object.assign({ partDate: item["DD_PARTITION_DATE"].value })
    );

    let tarnTieBreaker = Array.from(this.currentTransaction.values()).map(
      (item: any) =>
        Object.assign({ tarnTieBreaker: item["SD_TIEBREAKER"].value })
    );

    const portfolioIdParamsModel: PortfolioIdParamsModel =
      new PortfolioIdParamsModel();
    let partitionDate: any = formatDate(
      DD_PART_DATE[0].partDate,
      "yyyy-MM-dd",
      "en-US"
    );
    this.actionLvlId =
      this.dimensionIdStreamService.activeDimensionId.dimension;

    this.actionLvlIdTempList =
      this.dimensionIdStreamService.activeDimensionId.dimension;

    if (this.actionLvlId == 7) {
      portfolioIdParamsModel.tarnTieBreaker = tarnTieBreaker[0].tarnTieBreaker;
      portfolioIdParamsModel.ddPartDate = partitionDate;
      portfolioIdParamsModel.ndHashkey = ND_HASH_KEY[0].hashKey;
      portfolioIdParamsModel.recordSrcId = RECORD_SRC_ID[0].recorSrcId;
      portfolioIdParamsModel.actionLvlId = 1;

      this.emailService
        .getPortfolioId(portfolioIdParamsModel)
        .subscribe((data) => {
          if (data.P_PORTFOLIO_ID == null) {
            this.actionLvlId =
              this.dimensionIdStreamService.activeDimensionId.dimension;
            this.portfolioIds =
              this.dimensionIdStreamService.activeDimensionId.portfolioId;
            localStorage.setItem("portfId", this.portfolioIds);
            localStorage.setItem("acctlId", this.actionLvlId);
          } else {
            this.portfolioIds = data.P_PORTFOLIO_ID;
            this.actionLvlId = 1;
            localStorage.setItem("portfId", this.portfolioIds);
            localStorage.setItem("acctlId", this.actionLvlId);
          }
        });
    } else {
      this.actionLvlId =
        this.dimensionIdStreamService.activeDimensionId.dimension;
      this.portfolioIds =
        this.dimensionIdStreamService.activeDimensionId.portfolioId;
      localStorage.setItem("portfId", this.portfolioIds);
      localStorage.setItem("acctlId", this.actionLvlId);
    }

    setTimeout(() => {
      let acctlId = localStorage.getItem("acctlId");
      let portfId = localStorage.getItem("portfId");
      this.emailService
        .getIsKeyColumn(acctlId, portfId, this.sdMessageType)
        .subscribe((data) => {
          let is_key_column = data[0].ND_IS_KEY_NAME;
          this.channelName = data[0].CHANNEL_NAME;
          if (is_key_column == null || is_key_column == undefined) {
            this.globalNotificationService.showGlobalAlert(
              "Column Name Not Available",
              AlertLevel.WARNING
            );
          } else {
            localStorage.removeItem("acctlId");
            localStorage.removeItem("portfId");
            this.sdPortfolio = Array.from(this.currentTransaction.values()).map(
              (item: any) =>
                Object.assign({ portfolio: item[is_key_column].value })
            );

            this.sdPrtfolioId = this.sdPortfolio[0].portfolio;
            let actionLcvlId =
              this.dimensionIdStreamService.activeDimensionId.dimension;
            this.enableFlag.sdMessType = this.sdMessageType;
            this.enableFlag.sdPortfolio = this.sdPrtfolioId;
            this.enableFlag.actionLvlId = actionLcvlId;
            this.emailService
              .checkCsmField(this.enableFlag)
              .subscribe((data) => {
                if (data != 0) {
                  if (this.sdMessType !== null) {
                    this.emailService
                      .getChannelDetails(this.sdMessageType)
                      .subscribe((detail) => {
                        if (
                          this.channelName ==
                          HostAndChannelName.CHANNEL_NAMES[6]
                        ) {
                          if (this.actionLvlIdTempList == 1) {
                            this.emailService.channelId = detail[0].CHANNEL_ID;
                            this.emailService.actionLvlId =
                              detail[0].ACTION_LEVEL_ID;
                            this.emailService.portfolioId =
                              detail[0].PORTFOILO_IDS;
                            this.emailService.masterkeyCol =
                              detail[0].DETAIL_KEY_COLUMN_NAME;
                            this.emailService.csmId = detail[0].CSM_ID;
                            this.channel_id = detail[0].CHANNEL_ID;
                            this.channel_name = detail[0].CHANNEL_NAME;
                            this.actionLvlIdTemp = detail[0].ACTION_LEVEL_ID;
                          } else {
                            this.emailService.channelId = detail[1].CHANNEL_ID;
                            this.emailService.actionLvlId =
                              detail[1].ACTION_LEVEL_ID;
                            this.emailService.portfolioId =
                              detail[1].PORTFOILO_IDS;
                            this.emailService.masterkeyCol =
                              detail[1].DETAIL_KEY_COLUMN_NAME;
                            this.emailService.csmId = detail[1].CSM_ID;
                            this.channel_id = detail[1].CHANNEL_ID;
                            this.channel_name = detail[1].CHANNEL_NAME;
                            this.actionLvlIdTemp = detail[1].ACTION_LEVEL_ID;
                          }
                        } else if (
                          this.channelName ==
                          HostAndChannelName.CHANNEL_NAMES[7]
                        ) {
                          if (this.actionLvlIdTempList == 1) {
                            this.emailService.channelId = detail[2].CHANNEL_ID;
                            this.emailService.actionLvlId =
                              detail[2].ACTION_LEVEL_ID;
                            this.emailService.portfolioId =
                              detail[2].PORTFOILO_IDS;
                            this.emailService.masterkeyCol =
                              detail[2].DETAIL_KEY_COLUMN_NAME;
                            this.emailService.csmId = detail[2].CSM_ID;
                            this.channel_id = detail[2].CHANNEL_ID;
                            this.channel_name = detail[2].CHANNEL_NAME;
                            this.actionLvlIdTemp = detail[2].ACTION_LEVEL_ID;
                          } else {
                            this.emailService.channelId = detail[3].CHANNEL_ID;
                            this.emailService.actionLvlId =
                              detail[3].ACTION_LEVEL_ID;
                            this.emailService.portfolioId =
                              detail[3].PORTFOILO_IDS;
                            this.emailService.masterkeyCol =
                              detail[3].DETAIL_KEY_COLUMN_NAME;
                            this.emailService.csmId = detail[3].CSM_ID;
                            this.channel_id = detail[3].CHANNEL_ID;
                            this.channel_name = detail[3].CHANNEL_NAME;
                            this.actionLvlIdTemp = detail[3].ACTION_LEVEL_ID;
                          }
                        } else if (
                          this.channelName ==
                          HostAndChannelName.CHANNEL_NAMES[5]
                        ) {
                          this.emailService.channelId = detail[0].CHANNEL_ID;
                          this.emailService.actionLvlId =
                            detail[0].ACTION_LEVEL_ID;
                          this.emailService.portfolioId =
                            detail[0].PORTFOILO_IDS;
                          this.emailService.masterkeyCol =
                            detail[0].DETAIL_KEY_COLUMN_NAME;
                          this.emailService.csmId = detail[0].CSM_ID;
                          this.channel_id = detail[0].CHANNEL_ID;
                          this.channel_name = detail[0].CHANNEL_NAME;
                          this.actionLvlIdTemp = detail[0].ACTION_LEVEL_ID;
                        } else if (
                          this.channelName ==
                          HostAndChannelName.CHANNEL_NAMES[8]
                        ) {
                          this.emailService.channelId = detail[0].CHANNEL_ID;
                          this.emailService.actionLvlId =
                            detail[0].ACTION_LEVEL_ID;
                          this.emailService.portfolioId =
                            detail[0].PORTFOILO_IDS;
                          this.emailService.masterkeyCol =
                            detail[0].DETAIL_KEY_COLUMN_NAME;
                          this.emailService.csmId = detail[0].CSM_ID;
                          this.channel_id = detail[0].CHANNEL_ID;
                          this.channel_name = detail[0].CHANNEL_NAME;
                          this.actionLvlIdTemp = detail[0].ACTION_LEVEL_ID;
                        } else if (
                          this.channelName ==
                          HostAndChannelName.CHANNEL_NAMES[0]
                        ) {
                          if (this.actionLvlId == 6) {
                            this.emailService.channelId = detail[0].CHANNEL_ID;
                            this.emailService.actionLvlId =
                              detail[0].ACTION_LEVEL_ID;
                            this.emailService.portfolioId =
                              detail[0].PORTFOILO_IDS;
                            this.emailService.masterkeyCol =
                              detail[0].DETAIL_KEY_COLUMN_NAME;
                            this.emailService.csmId = detail[0].CSM_ID;
                            this.channel_id = detail[0].CHANNEL_ID;
                            this.channel_name = detail[0].CHANNEL_NAME;
                            this.actionLvlIdTemp = detail[0].ACTION_LEVEL_ID;
                          } else {
                            this.emailService.channelId = detail[1].CHANNEL_ID;
                            this.emailService.actionLvlId =
                              detail[1].ACTION_LEVEL_ID;
                            this.emailService.portfolioId =
                              detail[1].PORTFOILO_IDS;
                            this.emailService.masterkeyCol =
                              detail[1].DETAIL_KEY_COLUMN_NAME;
                            this.emailService.csmId = detail[1].CSM_ID;
                            this.channel_id = detail[1].CHANNEL_ID;
                            this.channel_name = detail[1].CHANNEL_NAME;
                            this.actionLvlIdTemp = detail[1].ACTION_LEVEL_ID;
                          }
                        }
                        // CBDC_Prasad
                        else if (
                          this.channelName ==
                          HostAndChannelName.CHANNEL_NAMES[9]
                        ) {
                          if (this.actionLvlId == 6) {
                            this.emailService.channelId = detail[0].CHANNEL_ID;
                            this.emailService.actionLvlId =
                              detail[0].ACTION_LEVEL_ID;
                            this.emailService.portfolioId =
                              detail[0].PORTFOILO_IDS;
                            this.emailService.masterkeyCol =
                              detail[0].DETAIL_KEY_COLUMN_NAME;
                            this.emailService.csmId = detail[0].CSM_ID;
                            this.channel_id = detail[0].CHANNEL_ID;
                            this.channel_name = detail[0].CHANNEL_NAME;
                            this.actionLvlIdTemp = detail[0].ACTION_LEVEL_ID;
                          } else {
                            this.emailService.channelId = detail[1].CHANNEL_ID;
                            this.emailService.actionLvlId =
                              detail[1].ACTION_LEVEL_ID;
                            this.emailService.portfolioId =
                              detail[1].PORTFOILO_IDS;
                            this.emailService.masterkeyCol =
                              detail[1].DETAIL_KEY_COLUMN_NAME;
                            this.emailService.csmId = detail[1].CSM_ID;
                            this.channel_id = detail[1].CHANNEL_ID;
                            this.channel_name = detail[1].CHANNEL_NAME;
                            this.actionLvlIdTemp = detail[1].ACTION_LEVEL_ID;
                          }
                        }
                        // YN20 Prasad
                        else if (
                          this.channelName ==
                          HostAndChannelName.CHANNEL_NAMES[10]
                        ) {
                          if (this.actionLvlId == 6) {
                            this.emailService.channelId = detail[0].CHANNEL_ID;
                            this.emailService.actionLvlId =
                              detail[0].ACTION_LEVEL_ID;
                            this.emailService.portfolioId =
                              detail[0].PORTFOILO_IDS;
                            this.emailService.masterkeyCol =
                              detail[0].DETAIL_KEY_COLUMN_NAME;
                            this.emailService.csmId = detail[0].CSM_ID;
                            this.channel_id = detail[0].CHANNEL_ID;
                            this.channel_name = detail[0].CHANNEL_NAME;
                            this.actionLvlIdTemp = detail[0].ACTION_LEVEL_ID;
                          } else {
                            this.emailService.channelId = detail[1].CHANNEL_ID;
                            this.emailService.actionLvlId =
                              detail[1].ACTION_LEVEL_ID;
                            this.emailService.portfolioId =
                              detail[1].PORTFOILO_IDS;
                            this.emailService.masterkeyCol =
                              detail[1].DETAIL_KEY_COLUMN_NAME;
                            this.emailService.csmId = detail[1].CSM_ID;
                            this.channel_id = detail[1].CHANNEL_ID;
                            this.channel_name = detail[1].CHANNEL_NAME;
                            this.actionLvlIdTemp = detail[1].ACTION_LEVEL_ID;
                          }
                        } else {
                          if (this.actionLvlId == 6) {
                            this.emailService.channelId = detail[0].CHANNEL_ID;
                            this.emailService.actionLvlId =
                              detail[0].ACTION_LEVEL_ID;
                            this.emailService.portfolioId =
                              detail[0].PORTFOILO_IDS;
                            this.emailService.masterkeyCol =
                              detail[0].DETAIL_KEY_COLUMN_NAME;
                            this.emailService.csmId = detail[0].CSM_ID;
                            this.channel_id = detail[0].CHANNEL_ID;
                            this.actionLvlIdTemp = detail[0].ACTION_LEVEL_ID;
                            this.channel_name = detail[0].CHANNEL_NAME;
                          } else {
                            this.emailService.channelId = detail[1].CHANNEL_ID;
                            this.emailService.actionLvlId =
                              detail[1].ACTION_LEVEL_ID;
                            this.emailService.portfolioId =
                              detail[1].PORTFOILO_IDS;
                            this.emailService.masterkeyCol =
                              detail[1].DETAIL_KEY_COLUMN_NAME;
                            this.emailService.csmId = detail[1].CSM_ID;
                            this.channel_id = detail[1].CHANNEL_ID;
                            this.channel_name = detail[1].CHANNEL_NAME;
                            this.actionLvlIdTemp = detail[1].ACTION_LEVEL_ID;
                          }
                        }

                        this.getEmailTemplates(
                          this.channel_id,
                          this.actionLvlIdTemp
                        );
                      });
                  } else {
                  }
                } else if (data == 0) {
                  this.globalNotificationService.showGlobalAlert(
                    "manual-email-addin.manual-email-actions.disabled",
                    AlertLevel.WARNING
                  );
                }
              });
          }
        });
    }, 1000);
  }

  get isSubmitDisabled() {
    return this.formGroup.invalid;
  }

  getEmailTemplates(channelId: any, actionLvlId: any) {
    this.emailService
      .getEmailTemplates(channelId, actionLvlId)
      .subscribe((templates) => {
        this.emailTemplates = templates;
      });
  }

  ngOnDestroy(): void {
    this.editor.destroy();
  }

  onChange(value: any) {
    if (value) {
      this.emailTemplates.forEach((template: any) => {
        if (template.TEMPLATE_ID == value) {
          this.formGroup.get("subject")?.setValue(template.EMAIL_SUBJECT);

          this.templateID = template.TEMPLATE_ID;

          const populateEmailModel: PopulateEmailModel =
            new PopulateEmailModel();

          let currentTransaction: any =
            this.dimensionIdStreamService.activeDimensionDetails
              .selectedTransactions;
          let actionLvlKey: any;
          let tarnTieBreaker: any;
          let sdHost: any;
          let tranDate: any;
          let templatePriority = template.TEMPLATE_PRIORITY;
          let RECORD_SRC_ID: any = Array.from(currentTransaction.values()).map(
            (item: any) =>
              Object.assign({ recorSrcId: item["RECORD_SOURCE_ID"].value })
          );
          let ND_HASH_KEY: any = Array.from(currentTransaction.values()).map(
            (item: any) => Object.assign({ hashKey: item["ND_KEY_HASH"].value })
          );
          let DD_PART_DATE: any = Array.from(currentTransaction.values()).map(
            (item: any) =>
              Object.assign({ partDate: item["DD_PARTITION_DATE"].value })
          );
          let partitionDate: any = formatDate(
            DD_PART_DATE[0].partDate,
            "yyyy-MM-dd",
            "en-US"
          );

          let sdPan = Array.from(currentTransaction.values()).map((item: any) =>
            Object.assign({ sdPan: item["SD_PAN"].value })
          );

          this.sdPan = sdPan[0].sdPan;

          // this.sdPortfolio = Array.from(currentTransaction.values()).map(
          //   (item: any) =>
          //     Object.assign({ portfolio: item["ND_USER_ACCT_ID_IS_KEY"].value })
          // );

          // this.portfolioId = this.sdPortfolio[0].portfolio;

          populateEmailModel.templateID = template.TEMPLATE_ID;
          populateEmailModel.templateText = template.TEMPLATE_TEXT;
          populateEmailModel.emailsubject = template.EMAIL_SUBJECT;

          actionLvlKey = Array.from(currentTransaction.values()).map(
            (item: any) =>
              Object.assign({
                actionLvlKey: item[this.emailService.masterkeyCol].value,
              })
          );

          this.actionLvlKey = actionLvlKey[0].actionLvlKey;

          populateEmailModel.actionLvlKey = this.actionLvlKey;
          tarnTieBreaker = Array.from(currentTransaction.values()).map(
            (item: any) =>
              Object.assign({ tarnTieBreaker: item["SD_TIEBREAKER"].value })
          );

          tranDate = Array.from(currentTransaction.values()).map((item: any) =>
            Object.assign({ tranDate: item["DD_DATE"].value })
          );

          this.txnDate = tranDate[0].tranDate;

          populateEmailModel.tranDate = this.txnDate;

          this.tieBreaker = tarnTieBreaker[0].tarnTieBreaker;

          let sdAcctNum = Array.from(currentTransaction.values()).map(
            (item: any) =>
              Object.assign({ sdAcctNum: item["SD_PRI_ACCT_NUM"].value })
          );

          this.SD_PRI_ACCT_NUM = sdAcctNum[0].sdAcctNum;

          if (this.channelName == HostAndChannelName.CHANNEL_NAMES[1]) {
            sdHost = Array.from(currentTransaction.values()).map((item: any) =>
              Object.assign({ sd_host: item["SD_HOST_DECISION"].value })
            );

            this.sdHost = sdHost[0].sd_host;
          }

          this.recordSrcId = RECORD_SRC_ID[0].recorSrcId;
          this.ndHashKey = ND_HASH_KEY[0].hashKey;
          this.partDate = partitionDate;

          populateEmailModel.tarnTieBreaker = this.tieBreaker;
          populateEmailModel.ddPartDate = this.partDate;
          populateEmailModel.ndHashkey = this.ndHashKey;
          populateEmailModel.recordSrcId = this.recordSrcId;
          if (this.channelName == HostAndChannelName.CHANNEL_NAMES[1]) {
            populateEmailModel.sdHostDecision = this.sdHost;
          } else {
            populateEmailModel.sdHostDecision = null;
          }

          this.emailService.getFeilds(populateEmailModel).subscribe((data) => {
            let toEmail = data.emailAddress;
            let ccEmail = data.ccEmailAddress;
            if (toEmail == " " || toEmail == null) {
              this.formGroup.get("mail_to")?.setValue("NA");
              this.emailToError = true;
              const Email_TO = document.getElementById("mail_to");
              Email_TO?.focus();
              let input: any = Email_TO?.getElementsByClassName("ar-input");
              input[0].classList.add("error");
            } else {
              // let emailTo = toEmail + ";";
              this.formGroup.get("mail_to")?.setValue(toEmail);
              const Email_TO = document.getElementById("mail_to");
              Email_TO?.focus();
              let input: any = Email_TO?.getElementsByClassName("ar-input");
              input[0].classList.remove("error");
              this.emailToError = false;
              // this.isRefreshBtnDesabled = true;
            }

            if (ccEmail == " " || ccEmail == null || ccEmail == "NA") {
              this.AddCC = false;
            } else {
              this.AddCC = true;
              this.formGroup.get("mail_cc")?.setValue(ccEmail);
            }

            this.uiFields = data.templateTxt;
          });
        }
      });

      this.emailService.getFromEmail().subscribe(
        (email) => {
          let FromEmail = email[0].SCFGVALUE;
          this.formGroup.get("mail_from")?.setValue(FromEmail);
        },
        (error) => {
          this.globalNotificationService.showGlobalAlertDirectMessage(
            error.error,
            AlertLevel.DANGER
          );
        }
      );

      if (this.channelName != HostAndChannelName.CHANNEL_NAMES[5]) {
        if (this.channelName == HostAndChannelName.CHANNEL_NAMES[1]) {
          if (this.sdHost == null || this.sdHost == undefined) {
            this.isDesabled = true;
            this.showRefresh = false;
            this.globalNotificationService.showGlobalAlert(
              "CINB-NO-SD-HOST",
              AlertLevel.WARNING
            );
          } else {
            if (
              this.sdHost.toUpperCase() ==
              HostAndChannelName.SD_HOST_DECISION[0]
            ) {
              this.send("onChange");
              this.showRefresh = true;
              this.formGroup.get("mail_to").reset();
              this.isDesabled = true;
            } else if (
              this.sdHost.toUpperCase() ==
              HostAndChannelName.SD_HOST_DECISION[1] ||
              this.sdHost.toUpperCase() ==
              HostAndChannelName.SD_HOST_DECISION[2]
            ) {
              this.showRefresh = false;
            } else if (
              this.sdHost.toUpperCase() !=
              HostAndChannelName.SD_HOST_DECISION[0] ||
              this.sdHost.toUpperCase() !=
              HostAndChannelName.SD_HOST_DECISION[1] ||
              this.sdHost.toUpperCase() !=
              HostAndChannelName.SD_HOST_DECISION[2]
            ) {
              this.isDesabled = true;
              this.showRefresh = false;
              this.globalNotificationService.showGlobalAlert(
                "CINB-NO-SD-HOST-SVV",
                AlertLevel.WARNING
              );
            }
          }
        } else {
          this.send("onChange");
          this.showRefresh = true;
          this.isDesabled = true;
          // this.formGroup.get("mail_to").reset();
        }
      } else {
        this.showRefresh = false;
      }

      this.formGroup.get("subject")?.enable();
      this.formGroup.get("mail_to")?.enable();
      this.formGroup.get("mail_cc")?.enable();
      this.formGroup.get("templateText")?.enable();
    }
  }

  removeClass(value: any) {
    if (value == "mail_to") {
      const toEmail = document.getElementById("mail_to");
      let input: any = toEmail?.getElementsByClassName("ar-input");
      input[0].classList.remove("error");
      this.emailToError = false;
      if (this.formGroup.valid) {
        this.isDesabled = false;
      } else {
        this.isDesabled = true;
      }
    } else if (value == "templatePriority") {
      const id = document.getElementById("templatePriority");
      let input: any = id?.getElementsByClassName("ar-input");
      input[0].classList.remove("error");
    }
  }

  validationMessages = () => {
    let commonString = "Please provide a";
    return {
      subject: {
        required: `${commonString} email subject.`,
      },
      email: {
        required: `${commonString} valid email`,
        pattern: "Not a valid email address",
      },
      templateText: {
        required: `${commonString} email body.`,
      },
    };
  };

  getErrToEmail() {
    let emailControl = this.controls.mail_to;
    return emailControl.hasError("required")
      ? this.validationMessages().email.required
      : emailControl.hasError("forbidden")
        ? this.validationMessages().email.pattern
        : "";
  }

  getErrFromEmail() {
    let emailControl = this.controls.mail_from;
    return emailControl.hasError("required")
      ? this.validationMessages().email.required
      : emailControl.hasError("forbidden")
        ? this.validationMessages().email.pattern
        : "";
  }

  getErrCCEmail() {
    let emailControl = this.controls.mail_cc;
    return emailControl.hasError("required")
      ? this.validationMessages().email.required
      : emailControl.hasError("pattern")
        ? this.validationMessages().email.pattern
        : "";
  }

  showError(controlName: string): boolean {
    return this.hasVisibleError(this.formGroup.get(controlName));
  }
  private hasVisibleError(control: AbstractControl): boolean {
    return control.invalid && (control.dirty || control.touched);
  }

  // Tracks whether the previous key was 'G' to catch sequences like "G then D"
  private awaitingSecondKeyAfterG = false;

  // Optionally constrain blocking to when focus is inside the editor:
  private isInEditor(el: EventTarget | null): boolean {
    // If you have a template ref (#ngxEditor), prefer querying its element.
    // Fallback: rely on contentEditable attribute presence up the tree.
    const node = el as HTMLElement | null;
    return !!node?.closest('[contenteditable="true"]');
  }

  onEditorClick() {
    this.cursPos = this.editor.view.state.selection.$anchor.pos - 1;
  }

  onEditorChange(content: any) {
    this.keyHandlerService.stopOtherTriggers();
    let value = this.formGroup.get("templateText")?.value;
    if (value == null || value == undefined) {
      this.isDesabled = true;
    } else {
      this.isDesabled = false;
    }

    if (value != null || value != undefined) {
      if (value == '<p></p>') {
        this.isDesabled = true;
      } else {
        this.isDesabled = false;
      }
    }
  }

  addCC() {
    if (!this.AddCC) {
      this.AddCC = true;
      this.formGroup.get("mail_cc")?.setValidators([this.commaSepEmail, Validators.required]);
    } else {
      this.AddCC = false;
      this.formGroup.get("mail_cc")?.reset();
      this.formGroup.get("mail_cc")?.clearValidators();
    }
    this.formGroup.get("mail_cc")?.updateValueAndValidity();
  }

  commaSepEmail = (control: AbstractControl): { [key: string]: any } | null => {
    if (!control.value) return null; // Allow empty value for optional fields

    const emails = control.value.split(";").map((e: string) => e.trim());
    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/;

    const invalidEmails = emails.filter((email: any) => !emailRegex.test(email));

    return invalidEmails.length ? { invalidEmails: invalidEmails } : null;
  };

  refresh() {
    // Code for send Request to get to and cc email id's from table;
    this.emailService
      .getEmailDetails(this.messageId, this.channel_name)
      .subscribe((data) => {
        if (data.CC_EMAIL_ID == null) {
          this.AddCC = false;
        } else {
          this.AddCC = true;
          this.formGroup.get("mail_cc").setValue(data.CC_EMAIL_ID);
        }
        if (data.TO_EMAIL_ID == null) {
          this.formGroup.get("mail_to").setValue("NA");
          this.isRefreshBtnDesabled = false;
          this.isDesabled = true;
        } else {
          this.formGroup.get("mail_to").setValue(data.TO_EMAIL_ID);
          this.isRefreshBtnDesabled = true;
          this.isDesabled = false;
        }
        if (data.ERROR_MESSAGE) {
          this.globalNotificationService.showGlobalAlertDirectMessage(
            `${data.ERROR_MESSAGE}`,
            AlertLevel.WARNING
          );
        }
      });
  }

  send(value: any) {
    let actionLvlKey;
    if (this.actionLvlId == "1") {
      actionLvlKey = this.sdPan;
    } else if (this.actionLvlId == "7" && this.channelName != HostAndChannelName.CHANNEL_NAMES[8]) {
      actionLvlKey = this.userAcctId;
    } else {
      actionLvlKey = this.actionLvlKey;
    }
    if (this.channelName == HostAndChannelName.CHANNEL_NAMES[1]) {
      if (value == "onChange") {
        this._sendEmail = Object.assign(
          new sendEmailFieldModel(),
          this.sendSMSFieldModel,
          {
            p_messageId: null,
            p_templateId: null,
            p_action_level_key: actionLvlKey,
            p_reviewerid: this.authService
              .getCurrentAuthenticationObject()
              .details.userId.substring(2),
            p_fromemail: null,
            p_toemail: null,
            p_ccemail: null,
            p_sd_tiebreaker: this.tieBreaker,
            p_templatetext: null,
            p_templatesubject: null,
            p_txn_date: this.txnDate,
            p_dd_partition_date: this.partDate,
            p_nd_hash_key: this.ndHashKey,
            p_record_source_id: this.recordSrcId,
            p_portfolio_id: this.portfolioIds,
            p_host_decision: this.sdHost,
            p_actionlevelid:
              this.dimensionIdStreamService.activeDimensionId.dimension,
            p_channelid: this.emailService.channelId,
            p_channelname: this.channel_name,
            p_account_no: this.SD_PRI_ACCT_NUM,
          }
        );
      } else if (value == "send") {
        this._sendEmail = Object.assign(
          new sendEmailFieldModel(),
          this.sendSMSFieldModel,
          {
            p_messageId: this.messageId,
            p_templateId: this.templateID,
            p_action_level_key: actionLvlKey,
            p_reviewerid: this.authService
              .getCurrentAuthenticationObject()
              .details.userId.substring(2),
            p_fromemail: this.formGroup.get("mail_from")?.value,
            p_toemail: this.formGroup.get("mail_to")?.value,
            p_ccemail: this.formGroup.get("mail_cc")?.value,
            p_sd_tiebreaker: this.tieBreaker,
            p_templatetext: this.uiFields,
            p_templatesubject: this.formGroup.get("subject")?.value,
            p_txn_date: this.txnDate,
            p_dd_partition_date: this.partDate,
            p_nd_hash_key: this.ndHashKey,
            p_record_source_id: this.recordSrcId,
            p_portfolio_id: this.portfolioIds,
            p_host_decision: this.sdHost,
            p_actionlevelid:
              this.dimensionIdStreamService.activeDimensionId.dimension,
            p_channelid: this.emailService.channelId,
            p_channelname: this.channel_name,
            p_account_no: this.SD_PRI_ACCT_NUM,
          }
        );
      }
    } else {
      if (value == "onChange") {
        this._sendEmail = Object.assign(
          new sendEmailFieldModel(),
          this.sendSMSFieldModel,
          {
            p_messageId: null,
            p_templateId: null,
            p_action_level_key: actionLvlKey,
            p_reviewerid: this.authService
              .getCurrentAuthenticationObject()
              .details.userId.substring(2),
            p_fromemail: null,
            p_toemail: null,
            p_ccemail: null,
            p_sd_tiebreaker: this.tieBreaker,
            p_templatetext: null,
            p_templatesubject: null,
            p_txn_date: this.txnDate,
            p_dd_partition_date: this.partDate,
            p_nd_hash_key: this.ndHashKey,
            p_record_source_id: this.recordSrcId,
            p_portfolio_id: this.portfolioIds,
            p_actionlevelid:
              this.dimensionIdStreamService.activeDimensionId.dimension,
            p_channelid: this.emailService.channelId,
            p_channelname: this.channel_name,
            p_account_no: this.SD_PRI_ACCT_NUM,
          }
        );
      } else if (value == "send") {
        this._sendEmail = Object.assign(
          new sendEmailFieldModel(),
          this.sendSMSFieldModel,
          {
            p_messageId: this.messageId,
            p_templateId: this.templateID,
            p_action_level_key: actionLvlKey,
            p_reviewerid: this.authService
              .getCurrentAuthenticationObject()
              .details.userId.substring(2),
            p_fromemail: this.formGroup.get("mail_from")?.value,
            p_toemail: this.formGroup.get("mail_to")?.value,
            p_ccemail: this.formGroup.get("mail_cc")?.value,
            p_sd_tiebreaker: this.tieBreaker,
            p_templatetext: this.uiFields,
            p_templatesubject: this.formGroup.get("subject")?.value,
            p_txn_date: this.txnDate,
            p_dd_partition_date: this.partDate,
            p_nd_hash_key: this.ndHashKey,
            p_record_source_id: this.recordSrcId,
            p_portfolio_id: this.portfolioIds,
            p_actionlevelid:
              this.dimensionIdStreamService.activeDimensionId.dimension,
            p_channelid: this.emailService.channelId,
            p_channelname: this.channel_name,
            p_account_no: this.SD_PRI_ACCT_NUM,
          }
        );
      }
    }

    this.emailService.sendEmail(this._sendEmail).subscribe(
      (data) => {
        let responseResult = data.P_RESULT_MESSAGE;
        let result = responseResult.split(`=`);
        let count = result[0].split("`");
        this.message = result[1].split("`");
        this.messageId = responseResult.split("=")[1].split(":")[1];
        if (count[0] == 0) {
          if (value == "send") {
            this._activeModal.close();
          }
          this.globalNotificationService.showGlobalAlertDirectMessage(
            `${this.message[1]}`,
            AlertLevel.SUCCESS
          );
        } else {
          this.globalNotificationService.showGlobalAlertDirectMessage(
            `${this.message[1]}`,
            AlertLevel.WARNING
          );
        }
        if (value == "send") {
          this.emailService.closeDialog.next(true);
        }
      },
      (error) => {
        this.modalAlert = new UntranslatedBootstrapAlert(
          AlertLevel.DANGER,
          error.message
        );
      }
    );
  }

  close() {
    this._activeModal.dismiss();
  }
}
