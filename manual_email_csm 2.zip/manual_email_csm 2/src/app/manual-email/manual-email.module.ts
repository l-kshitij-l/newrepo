import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule } from "@angular/forms";

import { ComponentLookupRegistry } from "@ar/components-lib";

import { OpenEmailTemplateReviewButtonComponent } from "./open-email-template-review-button/open-email-template-review-button.component";
import { EmailTemplateReviewDialogComponent } from "./email-template-review-dialog/email-template-review-dialog.component";
import { ArModule } from "./ar.module";
import { NgxEditorModule } from "ngx-editor";

@NgModule({
  declarations: [
    OpenEmailTemplateReviewButtonComponent,
    EmailTemplateReviewDialogComponent,
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    ArModule,
    NgxEditorModule
  ],
})
export class ManualEmailModule {
  constructor() {
    ComponentLookupRegistry.set(
      "app-open-email-template-review-button",
      OpenEmailTemplateReviewButtonComponent
    );
  }
}
