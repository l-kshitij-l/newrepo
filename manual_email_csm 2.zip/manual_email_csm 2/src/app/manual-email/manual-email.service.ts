import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthenticationService, CsrfTokenStore } from '@ar/auth-lib';
import { WebAddinRegistry } from '@ar/communication-lib';
import { DataGridRequestModel, PaginationModel, GridValueModel } from '@ar/components-lib';
import { BehaviorSubject, Observable, catchError, throwError } from 'rxjs';
import { checkFlag } from './model/is-Enable';
import { sendEmailFieldModel } from './model/sendEmail';
import { PopulateEmailModel } from './model/populateEmailModel';
import { PortfolioIdParamsModel } from './model/PortfolioIdParams';

@Injectable({
  providedIn: 'root'
})
export class ManualEmailService {

  channelId!:string;
  actionLvlId!:string;
  portfolioId!:string;
  masterkeyCol!:string;
  csmId!:string;

  
  constructor(private readonly _httpClient: HttpClient,
    private readonly _authenticationService: AuthenticationService) { }


    public closeDialog = new BehaviorSubject<any>(false);


    getPortfolioId(portfolioIdParamsModel: PortfolioIdParamsModel):Observable<any>{
      return this._httpClient.post<any>(`${this.getBaseUrl()}/manual-email/get-portfolio-id`,portfolioIdParamsModel,{headers: this.getHeaders(this._authenticationService)});
    }

    getEmailTemplates(channelId: number,actionLvlId: any):Observable<any>{
      return this._httpClient.get<any>(`${this.getBaseUrl()}/manual-email/get-email-template/${this.channelId}/${this.actionLvlId}`,{headers: this.getHeaders(this._authenticationService)});
    }

    getFromEmail():Observable<any>{
      return this._httpClient.get<any>(`${this.getBaseUrl()}/manual-email/get-from-email`,{headers: this.getHeaders(this._authenticationService)});
    }

    getChannelDetails(msgType:string){
      return this._httpClient.get<any>(`${this.getBaseUrl()}/manual-email/get-channel-detail/${msgType}`, {headers: this.getHeaders(this._authenticationService)});
    }
      
    getEmailFields(): Observable<any> {
      return this._httpClient.get<any>(`${this.getBaseUrl()}/manual-email/email-fields/${this.actionLvlId}/${this.channelId}`, {headers: this.getHeaders(this._authenticationService)});
    }

    getEmailDetails(msgId:any,channelName:any): Observable<any> {
      return this._httpClient.get<any>(`${this.getBaseUrl()}/manual-email/email-details/${msgId}/${channelName}`, {headers: this.getHeaders(this._authenticationService)});
    }
        
    getFeilds(populateEmailModel:PopulateEmailModel):  Observable<any> {
      populateEmailModel.actionlvlId=this.actionLvlId;
      populateEmailModel.channelId=this.channelId;
      populateEmailModel.csm_id=this.csmId;
      return this._httpClient.post<any>(`${this.getBaseUrl()}/manual-email/retrieve-email-feild-value`,populateEmailModel,{headers: this.getHeaders(this._authenticationService)});
      }

    getIsKeyColumn(actionLvlId:any,portfolioId:any,msgTyp:any){
      return this._httpClient.get<any>(`${this.getBaseUrl()}/manual-email/get-is-key-column/${actionLvlId}/${portfolioId}/${msgTyp}`, {headers: this.getHeaders(this._authenticationService)});
    }
    
    checkCsmField (mssageType :checkFlag) : Observable<any>{
      return this._httpClient.post<any>( this.getBaseUrl() + "/manual-email/csm-type",mssageType,
      {headers: this.getHeaders(this._authenticationService) }).pipe(catchError(this.handleError));
    }

    sendEmail(sendEmailFieldModel: sendEmailFieldModel):  Observable<any> {
    return this._httpClient.post<any>(`${this.getBaseUrl()}/manual-email/sendentrytomidepushtable`,sendEmailFieldModel,{headers: this.getHeaders(this._authenticationService)});
    }

    private handleError (error: HttpErrorResponse)
    {
      let errorMessage  = 'An error occured.';
      if (error.error instanceof ErrorEvent) {
        errorMessage = `Error : ${error.error.message}`;
        // A client-side or network error occurred.
      } else {
        // The backend returned an unsuccessful response code.
        // The response body may contain clues as to what went wrong.
        errorMessage =   `Error Code : ${error.status}\n Message : ${error.message}`;
        // console.error(
        //   `Backend returned code ${error.status}, body was: `, error.error);
  
      }
     
      return throwError(errorMessage);
    }

   getHeaders(_authenticationService: AuthenticationService): HttpHeaders{
    const token = CsrfTokenStore.CSRF_TOKEN;
    const session = _authenticationService.getSessionId(false);
    let httpHeaders = new HttpHeaders();

    if (session) {

       httpHeaders = httpHeaders.append('ar-plugin-authorization', `session ${session}`);
    }
    if (token) {
      httpHeaders = httpHeaders.append('X-XSRF-TOKEN', token?.token);
    }
    return httpHeaders;
  }


  getBaseUrl() {
    return WebAddinRegistry.loadConfiguration('ManualEmailModule').baseUrl;
  }
}
