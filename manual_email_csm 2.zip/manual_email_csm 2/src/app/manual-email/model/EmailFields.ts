export class EMAILFieldModel {
    emailFldId: string | undefined;
    emailFldName: string  | undefined;
    emailFldTable: string  | undefined;
  }
