export class PortfolioIdParamsModel{
    tarnTieBreaker:any |undefined;
    ddPartDate:any | undefined;
    ndHashkey:any | undefined;
    recordSrcId:any | undefined;
    actionLvlId:any |undefined;
 }