export class HostAndChannelName {
  static CHANNEL_NAMES: string[];
  static SD_HOST_DECISION: string[];
  static {
    this.CHANNEL_NAMES = [
      "RINB",
      "CINB",
      "UPI",
      "YONO",
      "YONO LITE",
      "FASTag",
      "CARD",
      "PREPAID CARD",
      "KIOSK",
      "CBDC",
      "YONO 2.0"
    ];

    this.SD_HOST_DECISION = ["SARAL", "VYAPAAR", "VISTAAR"];
  }
}
