export class checkFlag
{
    sdMessType : any;
    sdPortfolio : any;
    actionLvlId : any;
}