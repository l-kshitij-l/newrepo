export class PopulateEmailModel{
    templateID:any |undefined;
    templateText:any |undefined;
    emailsubject:any |undefined;
    actionLvlKey:any |undefined;
    actionlvlId:any |undefined;
    tarnTieBreaker:any |undefined;
    tranDate:any | undefined;
    ddPartDate:any | undefined;
    ndHashkey:any | undefined;
    recordSrcId:any | undefined;
    channelId:any |undefined;
    csm_id:any| undefined;
    sdHostDecision: any | undefined;
 }