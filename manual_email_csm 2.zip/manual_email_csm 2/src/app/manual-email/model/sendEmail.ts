export class sendEmailFieldModel {
    p_templateId: string | undefined;
    p_messageId: string | undefined;
    p_action_level_key: string | undefined;
    p_reviewerid: number | undefined;
    p_toemail: string | undefined;
    p_fromemail: string | undefined;
    p_ccemail: string | undefined;
    p_sd_tiebreaker: string | undefined;
    p_templatetext: string | undefined;
    p_templatesubject: string | undefined;
    p_txn_date: string | undefined;
    p_dd_partition_date: string | undefined;
    p_actionlevelid:string | undefined;
    p_channelid:string | undefined;
    p_channelname: string | undefined;
    p_account_no: string | undefined;
  }
  
  
  