import { Component, OnInit } from "@angular/core";
import { BaseDynamicComponent } from "../common/base-dynamic-component";
import { ArPermissionType, AuthenticationService } from "@ar/auth-lib";
import {
  ArModalService,
  GlobalNotificationService,
  ArIconService,
  AlertLevel,
  ReloadDataGridEventModel,
  ArTranslateService,
} from "@ar/components-lib";
import { DimensionIdStreamService } from "@ar/main-app";
import { ManualEmailService } from "../manual-email.service";
import { email_icon } from "../../../assets/icon";
import { EmailTemplateReviewDialogComponent } from "../email-template-review-dialog/email-template-review-dialog.component";
import { HostAndChannelName } from "../model/channel-name-and-host";
import { PortfolioIdParamsModel } from "../model/PortfolioIdParams";
import { formatDate } from "@angular/common";
import { checkFlag } from "../model/is-Enable";

@Component({
  selector: "app-open-email-template-review-button",
  templateUrl: "./open-email-template-review-button.component.html",
  styleUrls: ["./open-email-template-review-button.component.scss"],
})
export class OpenEmailTemplateReviewButtonComponent
  extends BaseDynamicComponent
  implements OnInit {
  tooltip: any;
  channelName: any;

  dimensionsMap = [
    { id: "6", values: "6-true" },
    { id: "7", values: "7-true" },
    { id: "1", values: "1-true" },
  ];
  portfolioIds: any;
  actionLvlId: any;
  currentTransaction: any;
  msgType: any;
  sdMessageType: any;
  sdMessType: any[];
  enableFlag: checkFlag = new checkFlag();
  sdPortfolio: any[];
  sdPrtfolioId: any;

  constructor(
    private dimensionIdStreamService: DimensionIdStreamService,
    private arModalService: ArModalService,
    private manualEmailService: ManualEmailService,
    private globalNotificationService: GlobalNotificationService,
    private authService: AuthenticationService,
    private iconService: ArIconService,
    private translation: ArTranslateService
  ) {
    super();

    this.iconService.registerInlineIcon("email", email_icon);
  }

  ngOnInit(): void { }

  actionDisabled() {
    if (
      !(
        this.dimensionIdStreamService.activeDimensionDetails
          .selectedTransactions?.size === 1
      )
    ) {
      this.tooltip = "manual-email-addin.review-email-actions.tooltip";
      return true;
    } else {
      this.tooltip = "manual-email-addin.review-email-grid-actions.tooltip";
      return false;
    }
  }

  shouldShowAction() {
    return (
      this.dimensionIdStreamService.activeDimensionId &&
      !this.dimensionIdStreamService.activeDimensionId.readonly
    );
  }

  openEmailSendDialog() {
    this.currentTransaction =
      this.dimensionIdStreamService.activeDimensionDetails.selectedTransactions;
    this.actionLvlId =
      this.dimensionIdStreamService.activeDimensionId.dimension;

    const portfolioIdParamsModel: PortfolioIdParamsModel =
      new PortfolioIdParamsModel();

    this.sdMessType = Array.from(this.currentTransaction.values()).map(
      (item: any) => Object.assign({ messsageType: item["SD_MSG_TYP"].value })
    );

    this.sdMessageType = this.sdMessType[0].messsageType;

    let RECORD_SRC_ID: any = Array.from(this.currentTransaction.values()).map(
      (item: any) =>
        Object.assign({ recorSrcId: item["RECORD_SOURCE_ID"].value })
    );
    let ND_HASH_KEY: any = Array.from(this.currentTransaction.values()).map(
      (item: any) => Object.assign({ hashKey: item["ND_KEY_HASH"].value })
    );
    let DD_PART_DATE: any = Array.from(this.currentTransaction.values()).map(
      (item: any) =>
        Object.assign({ partDate: item["DD_PARTITION_DATE"].value })
    );

    let tarnTieBreaker = Array.from(this.currentTransaction.values()).map(
      (item: any) =>
        Object.assign({ tarnTieBreaker: item["SD_TIEBREAKER"].value })
    );

    let partitionDate: any = formatDate(
      DD_PART_DATE[0].partDate,
      "yyyy-MM-dd",
      "en-US"
    );
    this.portfolioIds =
      this.dimensionIdStreamService.activeDimensionId.portfolioId;

    if (this.actionLvlId == 7) {
      portfolioIdParamsModel.tarnTieBreaker = tarnTieBreaker[0].tarnTieBreaker;
      portfolioIdParamsModel.ddPartDate = partitionDate;
      portfolioIdParamsModel.ndHashkey = ND_HASH_KEY[0].hashKey;
      portfolioIdParamsModel.recordSrcId = RECORD_SRC_ID[0].recorSrcId;
      portfolioIdParamsModel.actionLvlId = 1;

      this.manualEmailService
        .getPortfolioId(portfolioIdParamsModel)
        .subscribe((data) => {
          if (data.P_PORTFOLIO_ID == null) {
            this.actionLvlId =
              this.dimensionIdStreamService.activeDimensionId.dimension;
            this.portfolioIds =
              this.dimensionIdStreamService.activeDimensionId.portfolioId;
            this.manualEmailService
              .getIsKeyColumn(
                this.actionLvlId,
                this.portfolioIds,
                this.sdMessageType
              )
              .subscribe((data) => {
                if (!data.length) {
                  this.globalNotificationService.showGlobalAlert(
                    "manual-email.senddetails.error.response",
                    AlertLevel.WARNING
                  );
                } else {
                  let is_key_column = data[0].ND_IS_KEY_NAME;
                  this.channelName = data[0].CHANNEL_NAME;
                  if (is_key_column == null || is_key_column == undefined) {
                    this.globalNotificationService.showGlobalAlert(
                      "Column Name Not Available",
                      AlertLevel.WARNING
                    );
                  } else {
                    this.sdPortfolio = Array.from(
                      this.currentTransaction.values()
                    ).map((item: any) =>
                      Object.assign({ portfolio: item[is_key_column].value })
                    );

                    this.sdPrtfolioId = this.sdPortfolio[0].portfolio;
                    this.enableFlag.sdMessType = this.sdMessageType;
                    this.enableFlag.sdPortfolio = this.sdPrtfolioId;
                    this.enableFlag.actionLvlId = this.actionLvlId;
                    this.manualEmailService
                      .checkCsmField(this.enableFlag)
                      .subscribe((data) => {
                        if (data != 0) {
                          this.iskeyCol(this.actionLvlId, this.portfolioIds);
                        } else if (data == 0) {
                          this.globalNotificationService.showGlobalAlert(
                            "manual-email-addin.manual-email-actions.disabled",
                            AlertLevel.WARNING
                          );
                        }
                      });
                  }
                }
              });
          } else {
            this.portfolioIds = data.P_PORTFOLIO_ID;
            this.manualEmailService
              .getIsKeyColumn(
                this.actionLvlId,
                this.portfolioIds,
                this.sdMessageType
              )
              .subscribe((data) => {
                if (!data.length) {
                  this.globalNotificationService.showGlobalAlert(
                    "manual-email.senddetails.error.response",
                    AlertLevel.WARNING
                  );
                } else {
                  let is_key_column = data[0].ND_IS_KEY_NAME;
                  this.channelName = data[0].CHANNEL_NAME;
                  if (is_key_column == null || is_key_column == undefined) {
                    this.globalNotificationService.showGlobalAlert(
                      "Column Name Not Available",
                      AlertLevel.WARNING
                    );
                  } else {
                    let pIds = data[0].PORTFOLIO_IDS;

                    let sdPID = pIds.split(".").filter((el: any) => {
                      return el != "";
                    });

                    this.sdPrtfolioId = sdPID[1];
                    this.enableFlag.sdMessType = this.sdMessageType;
                    this.enableFlag.sdPortfolio = this.sdPrtfolioId;
                    this.enableFlag.actionLvlId = this.actionLvlId;
                    this.manualEmailService
                      .checkCsmField(this.enableFlag)
                      .subscribe((data) => {
                        if (data != 0) {
                          this.iskeyCol(this.actionLvlId, this.portfolioIds);
                        } else if (data == 0) {
                          this.globalNotificationService.showGlobalAlert(
                            "manual-email-addin.manual-email-actions.disabled",
                            AlertLevel.WARNING
                          );
                        }
                      });
                  }
                }
              });
          }
        });
    } else {
      this.actionLvlId =
        this.dimensionIdStreamService.activeDimensionId.dimension;
      this.portfolioIds =
        this.dimensionIdStreamService.activeDimensionId.portfolioId;
      this.sdPrtfolioId = this.portfolioIds;
      this.enableFlag.sdMessType = this.sdMessageType;
      this.enableFlag.sdPortfolio = this.sdPrtfolioId;
      this.enableFlag.actionLvlId = this.actionLvlId;
      this.manualEmailService
        .checkCsmField(this.enableFlag)
        .subscribe((data) => {
          if (data != 0) {
            this.iskeyCol(this.actionLvlId, this.portfolioIds);
          } else if (data == 0) {
            this.globalNotificationService.showGlobalAlert(
              "manual-email-addin.manual-email-actions.disabled",
              AlertLevel.WARNING
            );
          }
        });
    }
  }

  iskeyCol(acctlId: any, portfId: any) {
    this.manualEmailService
      .getIsKeyColumn(acctlId, portfId, this.sdMessageType)
      .subscribe((data) => {
        if (!data.length) {
          this.globalNotificationService.showGlobalAlert(
            "manual-email.senddetails.error.response",
            AlertLevel.WARNING
          );
        } else {
          this.channelName = data[0].CHANNEL_NAME;
          localStorage.removeItem("acctlId");
          localStorage.removeItem("portfId");
          if (this.channelName == HostAndChannelName.CHANNEL_NAMES[5]) {
            if (
              this.authService
                .getCurrentAuthenticationObject()
                .details.permissions.filter(
                  (e) =>
                    e.permissionType ===
                    (this.translation.translateLabel('permissions.manual-email-FASTag.permission') as ArPermissionType) &&
                    e.valueMatches.find((f) =>
                      this.dimensionsMap.some(
                        (s) =>
                          s.values === f &&
                          this.dimensionIdStreamService.activeDimensionId
                            .dimension === s.id
                      )
                    )
                ).length > 0
            ) {
              this.openEmailDialog();
            } else {
              this.globalNotificationService.showGlobalAlert(
                "fast-tag-Email.ftg-manual-Email-permission-tooltip",
                AlertLevel.WARNING
              );
            }
          } else if (this.channelName == HostAndChannelName.CHANNEL_NAMES[0]) {
            if (
              this.authService
                .getCurrentAuthenticationObject()
                .details.permissions.filter(
                  (e) =>
                    e.permissionType ===
                    (this.translation.translateLabel('permissions.manual-email-RINB.permission') as ArPermissionType) &&
                    e.valueMatches.find((f) =>
                      this.dimensionsMap.some(
                        (s) =>
                          s.values === f &&
                          this.dimensionIdStreamService.activeDimensionId
                            .dimension === s.id
                      )
                    )
                ).length > 0
            ) {
              this.openEmailDialog();
            } else {
              this.globalNotificationService.showGlobalAlert(
                "rinb-Email.rinb-manual-Email-permission-tooltip",
                AlertLevel.WARNING
              );
            }
          } else if (this.channelName == HostAndChannelName.CHANNEL_NAMES[1]) {
            if (
              this.authService
                .getCurrentAuthenticationObject()
                .details.permissions.filter(
                  (e) =>
                    e.permissionType ===
                    (this.translation.translateLabel('permissions.manual-email-CINB.permission') as ArPermissionType) &&
                    e.valueMatches.find((f) =>
                      this.dimensionsMap.some(
                        (s) =>
                          s.values === f &&
                          this.dimensionIdStreamService.activeDimensionId
                            .dimension === s.id
                      )
                    )
                ).length > 0
            ) {
              this.openEmailDialog();
            } else {
              this.globalNotificationService.showGlobalAlert(
                "cinb-Email.cinb-manual-Email-permission-tooltip",
                AlertLevel.WARNING
              );
            }
          } else if (this.channelName == HostAndChannelName.CHANNEL_NAMES[2]) {
            if (
              this.authService
                .getCurrentAuthenticationObject()
                .details.permissions.filter(
                  (e) =>
                    e.permissionType ===
                    (this.translation.translateLabel('permissions.manual-email-UPI.permission') as ArPermissionType) &&
                    e.valueMatches.find((f) =>
                      this.dimensionsMap.some(
                        (s) =>
                          s.values === f &&
                          this.dimensionIdStreamService.activeDimensionId
                            .dimension === s.id
                      )
                    )
                ).length > 0
            ) {
              this.openEmailDialog();
            } else {
              this.globalNotificationService.showGlobalAlert(
                "upi-Email.upi-manual-Email-permission-tooltip",
                AlertLevel.WARNING
              );
            }
          } else if (this.channelName == HostAndChannelName.CHANNEL_NAMES[3]) {
            if (
              this.authService
                .getCurrentAuthenticationObject()
                .details.permissions.filter(
                  (e) =>
                    e.permissionType ===
                    (this.translation.translateLabel('permissions.manual-email-YONO.permission') as ArPermissionType) &&
                    e.valueMatches.find((f) =>
                      this.dimensionsMap.some(
                        (s) =>
                          s.values === f &&
                          this.dimensionIdStreamService.activeDimensionId
                            .dimension === s.id
                      )
                    )
                ).length > 0
            ) {
              this.openEmailDialog();
            } else {
              this.globalNotificationService.showGlobalAlert(
                "yno-Email.yno-manual-Email-permission-tooltip",
                AlertLevel.WARNING
              );
            }
          } else if (this.channelName == HostAndChannelName.CHANNEL_NAMES[4]) {
            if (
              this.authService
                .getCurrentAuthenticationObject()
                .details.permissions.filter(
                  (e) =>
                    e.permissionType ===
                    (this.translation.translateLabel('permissions.manual-email-YONOLite.permission') as ArPermissionType) &&
                    e.valueMatches.find((f) =>
                      this.dimensionsMap.some(
                        (s) =>
                          s.values === f &&
                          this.dimensionIdStreamService.activeDimensionId
                            .dimension === s.id
                      )
                    )
                ).length > 0
            ) {
              this.openEmailDialog();
            } else {
              this.globalNotificationService.showGlobalAlert(
                "ylit-Email.ylit-manual-Email-permission-tooltip",
                AlertLevel.WARNING
              );
            }
          } else if (this.channelName == HostAndChannelName.CHANNEL_NAMES[7]) {
            if (
              this.authService
                .getCurrentAuthenticationObject()
                .details.permissions.filter(
                  (e) =>
                    e.permissionType ===
                    (this.translation.translateLabel('permissions.manual-email-PREPAIDCARD.permission') as ArPermissionType) &&
                    e.valueMatches.find((f) =>
                      this.dimensionsMap.some(
                        (s) =>
                          s.values === f &&
                          this.dimensionIdStreamService.activeDimensionId
                            .dimension === s.id
                      )
                    )
                ).length > 0
            ) {
              this.openEmailDialog();
            } else {
              this.globalNotificationService.showGlobalAlert(
                "prepaid-card-Email.prepaid-card-manual-Email-permission-tooltip",
                AlertLevel.WARNING
              );
            }
          } else if (this.channelName == HostAndChannelName.CHANNEL_NAMES[6]) {
            if (
              this.authService
                .getCurrentAuthenticationObject()
                .details.permissions.filter(
                  (e) =>
                    e.permissionType ===
                    (this.translation.translateLabel('permissions.manual-email-CARD.permission') as ArPermissionType) &&
                    e.valueMatches.find((f) =>
                      this.dimensionsMap.some(
                        (s) =>
                          s.values === f &&
                          this.dimensionIdStreamService.activeDimensionId
                            .dimension === s.id
                      )
                    )
                ).length > 0
            ) {
              this.openEmailDialog();
            } else {
              this.globalNotificationService.showGlobalAlert(
                "card-Email.card-manual-Email-permission-tooltip",
                AlertLevel.WARNING
              );
            }
          } else if (this.channelName == HostAndChannelName.CHANNEL_NAMES[8]) {
            if (
              this.authService
                .getCurrentAuthenticationObject()
                .details.permissions.filter(
                  (e) =>
                    e.permissionType ===
                    (this.translation.translateLabel('permissions.manual-email-KIOSK.permission') as ArPermissionType) &&
                    e.valueMatches.find((f) =>
                      this.dimensionsMap.some(
                        (s) =>
                          s.values === f &&
                          this.dimensionIdStreamService.activeDimensionId
                            .dimension === s.id
                      )
                    )
                ).length > 0
            ) {
              this.openEmailDialog();
            } else {
              this.globalNotificationService.showGlobalAlert(
                "kisk-Email.kisk-manual-Email-permission-tooltip",
                AlertLevel.WARNING
              );
            }
          } else if (this.channelName == HostAndChannelName.CHANNEL_NAMES[9]) {
            if (
              this.authService
                .getCurrentAuthenticationObject()
                .details.permissions.filter(
                  (e) =>
                    e.permissionType ===
                    (this.translation.translateLabel('permissions.manual-email-CBDC.permission') as ArPermissionType) &&
                    e.valueMatches.find((f) =>
                      this.dimensionsMap.some(
                        (s) =>
                          s.values === f &&
                          this.dimensionIdStreamService.activeDimensionId
                            .dimension === s.id
                      )
                    )
                ).length > 0
            ) {
              this.openEmailDialog();
            } else {
              this.globalNotificationService.showGlobalAlert(
                "cbdc-Email.cbdc-manual-Email-permission-tooltip",
                AlertLevel.WARNING
              );
            }
          } else if (this.channelName == HostAndChannelName.CHANNEL_NAMES[10]) {
            if (
              this.authService
                .getCurrentAuthenticationObject()
                .details.permissions.filter(
                  (e) =>
                    e.permissionType ===
                    (this.translation.translateLabel('permissions.manual-email-YN20.permission') as ArPermissionType) &&
                    e.valueMatches.find((f) =>
                      this.dimensionsMap.some(
                        (s) =>
                          s.values === f &&
                          this.dimensionIdStreamService.activeDimensionId
                            .dimension === s.id
                      )
                    )
                ).length > 0
            ) {
              this.openEmailDialog();
            } else {
              this.globalNotificationService.showGlobalAlert(
                "yn20-Email.yn20-manual-Email-permission-tooltip",
                AlertLevel.WARNING
              );
            }
          }
        }
      }
      );
  }

  openEmailDialog() {
    this.manualEmailService.closeDialog.next(false);

    const modelRef = this.arModalService.open(
      EmailTemplateReviewDialogComponent
    );
    modelRef.result?.then((status: any) => {
      this.emitEvent(new ReloadDataGridEventModel("actions-history-grid"));
    });
  }
}
