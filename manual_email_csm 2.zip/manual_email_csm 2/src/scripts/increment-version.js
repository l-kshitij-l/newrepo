const fs = require('fs');
const path = require('path');
const readline = require('readline');
 
// Specify the correct path to package.json (relative to the scripts folder)
const packageJsonPath = path.join(__dirname, '..', '..', 'package.json'); // Goes up one level to `src/` folder
 
// Read the package.json file
const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
 
// Get the current version
let version = packageJson.version;
console.log(`Current version: ${version}`);
 
// Split the version into major, minor, and patch components
const versionParts = version.split('.').map(Number);
 
// Create an interface to accept user input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});
 
// Prompt the user for the increment type
rl.question('Enter version increment type (major, minor, patch, or NA to keep current version): ', (incrementType) => {
  // If user enters 'NA', don't update the version
  if (incrementType.toUpperCase() === 'NA' || incrementType.toLowerCase() === 'na' || incrementType === '' || incrementType === undefined) {
    console.log('Version will remain unchanged.');
    rl.close();
    return; // Exit without updating the version
  }
 
  // Validate the input or set default value
  incrementType = incrementType || 'patch';
 
  console.log(`Incrementing version by: ${incrementType}`);
 
  // Perform the version increment
  switch (incrementType) {
    case 'major':
      versionParts[0]++;  // Increment the major version
      versionParts[1] = 0; // Reset the minor version
      versionParts[2] = 0; // Reset the patch version
      break;
 
    case 'minor':
      versionParts[1]++;  // Increment the minor version
      versionParts[2] = 0; // Reset the patch version
      break;
 
    case 'patch':
    default:
      versionParts[2]++;  // Increment the patch version
      break;
  }
 
  // Update the version number
  const newVersion = versionParts.join('.');
  packageJson.version = newVersion;
 
  console.log(`New version: ${newVersion}`);
 
  // Write the updated package.json back to the file
  fs.writeFileSync(packageJsonPath, JSON.stringify(packageJson, null, 2), 'utf8');
 
  // Close the readline interface
  rl.close();
});