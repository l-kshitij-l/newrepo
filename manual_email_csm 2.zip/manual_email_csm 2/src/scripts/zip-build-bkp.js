const archiver = require('archiver');

const fs = require('fs');

const output = fs.createWriteStream('./dist/manual-email.zip');

const archive = archiver('zip', {zlib: {level: 9}});

output.on('close',()=>{
    console.log(archive.pointer() + ' total bytes');
    console.log('Zip file has been created successfully');
});

archive.on('warning',(err)=>{
    if(err.code === 'ENOENT'){
        console.log(err);
    }else{
        throw err;
    }
});

archive.on('error',(err)=>{
    throw err;
});

archive.pipe(output);
archive.directory('dist/manual-email', false);
archive.finalize();
