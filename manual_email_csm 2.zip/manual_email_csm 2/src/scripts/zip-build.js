const archiver = require('archiver');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

const packageJsonPath = path.join(__dirname, '..', '..', 'package.json'); // Goes up one level to `src/` folder

// Read the package.json file
const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));

// Create an interface to accept user input
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Prompt the user for the increment type
rl.question('Enter tenant name (CINB, FO, SBI, NA, or multiple separated by comma): ', (TENANT_NAMES) => {
    // Split the input into an array of tenant names
    const tenants = TENANT_NAMES.split(',').map(tenant => tenant.trim());

    // If user enters 'NA', don't update the version for the domestic tenant
    const validTenants = tenants.filter(tenant => {
        return tenant.toUpperCase() !== 'NA' && tenant !== '';
    });

    // If no valid tenants, set to default (SBI) for the build
    if (validTenants.length === 0) {
        validTenants.push('SBI');
        console.log('No valid tenant names entered. Defaulting to "SBI".');
    }

    // Function to create the zip file for each tenant
    const createZipFile = (tenantName) => {
        return new Promise((resolve, reject) => {
            const output = fs.createWriteStream(`./dist/manual-email_${tenantName}_v${packageJson.version}.zip`);
            const archive = archiver('zip', { zlib: { level: 9 } });

            output.on('close', () => {
                console.log(`${tenantName}: ${archive.pointer()} total bytes`);
                console.log(`${tenantName}: Zip file has been created successfully`);
                resolve();
            });

            archive.on('warning', (err) => {
                if (err.code === 'ENOENT') {
                    console.log(err);
                } else {
                    reject(err);
                }
            });

            archive.on('error', (err) => {
                reject(err);
            });

            archive.pipe(output);
            archive.directory('dist/manual-email', false);
            archive.finalize();
        });
    };

    // Create an array of promises for each tenant zip creation
    const zipPromises = validTenants.map(tenant => createZipFile(tenant));

    // Wait for all zip creation tasks to complete
    Promise.all(zipPromises)
        .then(() => {
            console.log('All zip files have been created successfully.');
            rl.close();
        })
        .catch((err) => {
            console.error('An error occurred during zip creation:', err);
            rl.close();
        });
});
